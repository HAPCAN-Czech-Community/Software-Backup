//---------------------------------------------------------------------------

#ifndef pagepropH
#define pagepropH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <ExtDlgs.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TPageProperties : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TImage *Image0;
        TEdit *Edit1;
        TGroupBox *GroupBox3;
        TBitBtn *BitBtn3;
        TBitBtn *BitBtn2;
        TBitBtn *BitBtn1;
        TGroupBox *GroupBox4;
        TMemo *Memo1;
        TOpenPictureDialog *OpenPictureDialog1;
        TBitBtn *BitBtn4;
        TPanel *Panel1;
        TBitBtn *BitBtn5;
        TColorDialog *ColorDialog1;
        TImage *Image1;
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall BitBtn2Click(TObject *Sender);
        void __fastcall BitBtn3Click(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall BitBtn4Click(TObject *Sender);
        void __fastcall BitBtn5Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TPageProperties(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPageProperties *PageProperties;
//---------------------------------------------------------------------------
#endif
