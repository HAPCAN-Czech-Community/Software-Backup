//---------------------------------------------------------------------------

#ifndef menuH
#define menuH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TFormMenu : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TPanel *PanelEdit;
        TLabel *Label2;
        TImage *Image2;
        TPanel *PanelCancel;
        TLabel *Label4;
        TImage *Image4;
        TPanel *PanelReconnect;
        TLabel *Label1;
        TImage *Image1;
        void __fastcall PanelEditClick(TObject *Sender);
        void __fastcall PanelCancelClick(TObject *Sender);
        void __fastcall PanelReconnectClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFormMenu(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormMenu *FormMenu;
//---------------------------------------------------------------------------
#endif
