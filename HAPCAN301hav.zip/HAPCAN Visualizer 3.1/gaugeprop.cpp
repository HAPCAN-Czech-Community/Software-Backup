//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <IniFiles.hpp>
#include "gaugeprop.h"
#include "main.h"
#include "functions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CGAUGES"
#pragma resource "*.dfm"
TGaugeProperties *GaugeProperties;

//extern
extern TIniFile *tmp;                //project tmp file
extern ChosenGauge;
extern TPanel *IconGauge[];
extern TCGauge *gauge[];
extern AnsiString DialogCommand;
extern AnsiString ProjectPath;

//---------------------------------------------------------------------------
__fastcall TGaugeProperties::TGaugeProperties(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGaugeProperties::FormActivate(TObject *Sender)
{
        GaugeProperties->Caption = "Gauge "+IntToStr(ChosenGauge);              //form title
        if(DialogCommand == "new")                                              //new command
        {
           for(int i=1; i<=4; i++)                                              //clear edits
           {
              TEdit *EachEdit = dynamic_cast<TEdit *>(FindComponent("Edit" + IntToStr(i)));
              EachEdit->Text="";
           }
           Memo1->Text = "Note";
        }
        if(DialogCommand == "edit")                                             //edit command
        {
           Edit1->Text = tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"Name","");
           Edit2->Text = tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"OnMouseDown","");
           Edit3->Text = tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"OnMouseUp","");
           Edit4->Text = tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"ShowValueIf","");
           CGauge2->Width = tmp->ReadInteger("Gauge "+IntToStr(ChosenGauge),"Width",20);
           CGauge2->Height = tmp->ReadInteger("Gauge "+IntToStr(ChosenGauge),"Height",33);
           //colors
              CGauge2->ForeColor = (TColor)StrToIntDef(tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"ForeColor","0x008000"),0x008000);
              CGauge2->BackColor = (TColor)StrToIntDef(tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"BackColor","0xFFFFFF"),0xFFFFFF);
           //text
           CGauge2->ShowText = tmp->ReadBool("Gauge "+IntToStr(ChosenGauge),"ShowText",true);
           //border
           CGauge2->BorderStyle = CGauge2->BorderStyle << bsClear;
           if(tmp->ReadBool("Gauge "+IntToStr(ChosenGauge),"ShowBorder",true)==true)
           {
              CGauge2->BorderStyle = bsSingle;
              CheckBox2->Checked = true;
           }
           else
           {
              CGauge2->BorderStyle = bsNone;
              CheckBox2->Checked = false;
           }
           Memo1->Text = tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"Note","");
           
           CheckBox1->Checked = CGauge2->ShowText;
           CSpinEdit1->Value = CGauge2->Width;
           CSpinEdit2->Value = CGauge2->Height;
        }                                            
}
//---------------------------------------------------------------------------
void __fastcall TGaugeProperties::BitBtn2Click(TObject *Sender)
{
        //Name must be entered
        if(Edit1->Text=="")
        {
           ShowMessage("Enter Gauge Name");
           return;
        }
        IconGauge[ChosenGauge]->Width = CGauge2->Width;
        IconGauge[ChosenGauge]->Height = CGauge2->Height;
        gauge[ChosenGauge]->ForeColor = CGauge2->ForeColor;
        gauge[ChosenGauge]->BackColor = CGauge2->BackColor;
        gauge[ChosenGauge]->ShowText = CheckBox1->Checked;
        if(CheckBox2->Checked)
           gauge[ChosenGauge]->BorderStyle = bsSingle;
        else
           gauge[ChosenGauge]->BorderStyle = bsNone;
        //save to tmp
        tmp->WriteString("Gauge "+IntToStr(ChosenGauge),"Name",Edit1->Text);
        tmp->WriteInteger("Gauge "+IntToStr(ChosenGauge),"Page",Form1->PageControl1->ActivePageIndex);
        tmp->WriteInteger("Gauge "+IntToStr(ChosenGauge),"PositionX",IconGauge[ChosenGauge]->Left);
        tmp->WriteInteger("Gauge "+IntToStr(ChosenGauge),"PositionY",IconGauge[ChosenGauge]->Top);
        tmp->WriteString("Gauge "+IntToStr(ChosenGauge),"OnMouseDown",Trim(Edit2->Text));
        tmp->WriteString("Gauge "+IntToStr(ChosenGauge),"OnMouseUp",Trim(Edit3->Text));
        tmp->WriteString("Gauge "+IntToStr(ChosenGauge),"ShowValueIf",Edit4->Text);
        tmp->WriteInteger("Gauge "+IntToStr(ChosenGauge),"Width",CGauge2->Width);
        tmp->WriteInteger("Gauge "+IntToStr(ChosenGauge),"Height",CGauge2->Height);
        tmp->WriteString("Gauge "+IntToStr(ChosenGauge),"ForeColor","0x"+IntToHex(CGauge2->ForeColor,6));
        tmp->WriteString("Gauge "+IntToStr(ChosenGauge),"BackColor","0x"+IntToHex(CGauge2->BackColor,6));
        tmp->WriteBool("Gauge "+IntToStr(ChosenGauge),"ShowText",CheckBox1->Checked);
        tmp->WriteBool("Gauge "+IntToStr(ChosenGauge),"ShowBorder",CheckBox2->Checked);
        //memo
        if(DialogCommand == "new")                                              //if new object add line
           Memo1->Lines->Add("");
        tmp->WriteString("Gauge "+IntToStr(ChosenGauge),"Note",Memo1->Text);
        //project modified
        ProjectModified(1);

        Close();
        ModalResult = mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TGaugeProperties::BitBtn3Click(TObject *Sender)
{
        ColorDialog1->Color = CGauge2->ForeColor;     //show current color
        if (ColorDialog1->Execute())
           CGauge2->ForeColor = ColorDialog1->Color;
}
//---------------------------------------------------------------------------
void __fastcall TGaugeProperties::BitBtn4Click(TObject *Sender)
{
        ColorDialog1->Color = CGauge2->BackColor;     //show current color
        if (ColorDialog1->Execute())
           CGauge2->BackColor = ColorDialog1->Color;
}
//---------------------------------------------------------------------------
void __fastcall TGaugeProperties::CSpinEdit1Change(TObject *Sender)
{
        CGauge2->Width = CSpinEdit1->Value;
}
//---------------------------------------------------------------------------
void __fastcall TGaugeProperties::CSpinEdit2Change(TObject *Sender)
{
        CGauge2->Height = CSpinEdit2->Value;
}
//---------------------------------------------------------------------------
void __fastcall TGaugeProperties::CheckBox1Click(TObject *Sender)
{
        if(CheckBox1->Checked)
           CGauge2->ShowText = true;
        else
           CGauge2->ShowText = false;
}
//---------------------------------------------------------------------------
void __fastcall TGaugeProperties::CheckBox2Click(TObject *Sender)
{
        if(CheckBox2->Checked)
           CGauge2->BorderStyle = bsSingle;
        else
           CGauge2->BorderStyle = bsNone;
}
//---------------------------------------------------------------------------
void __fastcall TGaugeProperties::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
        if (Key == VK_ESCAPE)
        {
           Close();
           ModalResult = mrCancel;
        }
}
//---------------------------------------------------------------------------

