//---------------------------------------------------------------------------
#ifndef functionsH
#define functionsH
//---------------------------------------------------------------------------
void __fastcall ProjectModified(bool yesorno);
AnsiString __fastcall DNSLookUp(AnsiString Adres);
//---------------------------------------------------------------------------
#endif
 