//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("main.cpp", Form1);
USEFORM("settings.cpp", FormSettings);
USEFORM("textprop.cpp", TextProperties);
USEFORM("imageprop.cpp", ImageProperties);
USEFORM("about.cpp", FormAbout);
USEFORM("gaugeprop.cpp", GaugeProperties);
USEFORM("pageprop.cpp", PageProperties);
USEFORM("menu.cpp", FormMenu);
USEFORM("rgb.cpp", Win_RGB);
USEFORM("popup.cpp", PopUp);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->Title = "HAPCAN Visualizer";
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TFormSettings), &FormSettings);
                 Application->CreateForm(__classid(TTextProperties), &TextProperties);
                 Application->CreateForm(__classid(TImageProperties), &ImageProperties);
                 Application->CreateForm(__classid(TFormAbout), &FormAbout);
                 Application->CreateForm(__classid(TGaugeProperties), &GaugeProperties);
                 Application->CreateForm(__classid(TPageProperties), &PageProperties);
                 Application->CreateForm(__classid(TFormMenu), &FormMenu);
                 Application->CreateForm(__classid(TWin_RGB), &Win_RGB);
                 Application->CreateForm(__classid(TPopUp), &PopUp);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
