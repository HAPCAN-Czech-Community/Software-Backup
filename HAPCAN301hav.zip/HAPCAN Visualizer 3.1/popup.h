//---------------------------------------------------------------------------

#ifndef popupH
#define popupH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TPopUp : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TLabel *Label1;
private:	// User declarations
public:		// User declarations
        __fastcall TPopUp(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPopUp *PopUp;
//---------------------------------------------------------------------------
#endif
