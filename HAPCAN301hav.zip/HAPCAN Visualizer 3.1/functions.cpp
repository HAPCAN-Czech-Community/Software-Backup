//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#include <fstream>
#pragma hdrstop

#include "functions.h"
#include "main.h"
#include "WinDns.h"
#include "Winsock.h"
#pragma package(smart_init)

//variable
extern ProjectModifiedFlag;

//---------------------------------------------------------------------------
void __fastcall ProjectModified(bool yesorno)
{
        if(yesorno)
        {
           ProjectModifiedFlag = 1;                                     //set flag
           Form1->MainMenu1->Items->Items[0]->Items[2]->Enabled = true; //show save option
        }
        else
        {
           ProjectModifiedFlag = 0;
           Form1->MainMenu1->Items->Items[0]->Items[2]->Enabled = false;
        }
}
//---------------------------------------------------------------------------
AnsiString __fastcall DNSLookUp(AnsiString Adres)
{
   DNS_STATUS status;                      //zwrot DnsQuery_A()
   DNS_RECORD* pDnsRecord = NULL;          //wkaznik do struktury DNS_RECORD
   IN_ADDR ipaddr;                         //adres IP
   AnsiString AdresIP;                     //kropkowany adres IP


   status = DnsQuery_A(Adres.c_str(),                          //pytanie o..
                       DNS_TYPE_A,                             //typ wyniku
                       DNS_QUERY_BYPASS_CACHE,                 //typ pytania
                       NULL,                                   //domyslny dns serwer
                       &pDnsRecord,                            //wynik
                       NULL);                                  //rezerwa

    if (status)
    {
       ShowMessage("DNS error. It is not possible to retrieve IP address.");
       AdresIP = NULL;
    }
    else
    {
       //zamien adres internetowy na kropkowany
       ipaddr.S_un.S_addr = (pDnsRecord->Data.A.IpAddress);
       AdresIP = inet_ntoa(ipaddr);
       //zwolnij pamiec DNS
       DnsRecordListFree(pDnsRecord, DnsFreeRecordList);
     }
return AdresIP;
}
