//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <IniFiles.hpp>
#include "textprop.h"
#include "main.h"
#include "functions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTextProperties *TextProperties;

//extern
extern TIniFile *tmp;                //project tmp file
extern ChosenText;
extern TLabel *IconText[];
extern AnsiString DialogCommand;
extern AnsiString ProjectPath;

//---------------------------------------------------------------------------
__fastcall TTextProperties::TTextProperties(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTextProperties::FormActivate(TObject *Sender)
{
        TextProperties->Caption = "Text "+IntToStr(ChosenText);               //form title
        if(DialogCommand == "new")                                              //new command
        {
           for(int i=1; i<=7; i++)                                              //clear edits
           {
              TEdit *EachEdit = dynamic_cast<TEdit *>(FindComponent("Edit" + IntToStr(i)));
              EachEdit->Text="";
           }
           Memo1->Text = "Note";
        }
        if(DialogCommand == "edit")                                             //edit command
        {
           Edit1->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"Name","");
           Edit2->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"OnMouseDown","");
           Edit3->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"OnMouseUp","");
           FontDialog1->Font->Name = tmp->ReadString("Text "+IntToStr(ChosenText),"FontName1","MS Sans Serif");
           FontDialog1->Font->Size = tmp->ReadInteger("Text "+IntToStr(ChosenText),"FontSize1",8);
           //style
           FontDialog1->Font->Style = FontDialog1->Font->Style.Clear();
           if((tmp->ReadString(("Text "+IntToStr(ChosenText)),"FontStyle1","").Pos("bold"))!=0)
              FontDialog1->Font->Style = FontDialog1->Font->Style << fsBold;
           if((tmp->ReadString(("Text "+IntToStr(ChosenText)),"FontStyle1","").Pos("italic"))!=0)
              FontDialog1->Font->Style = FontDialog1->Font->Style << fsItalic;
           if((tmp->ReadString(("Text "+IntToStr(ChosenText)),"FontStyle1","").Pos("underline"))!=0)
              FontDialog1->Font->Style = FontDialog1->Font->Style << fsUnderline;
           if((tmp->ReadString(("Text "+IntToStr(ChosenText)),"FontStyle1","").Pos("strikeout"))!=0)
              FontDialog1->Font->Style = FontDialog1->Font->Style << fsStrikeOut;
           //color
              FontDialog1->Font->Color = (TColor)StrToIntDef(tmp->ReadString("Text "+IntToStr(ChosenText),"FontColor1","0x000000"),0x000000);

           Edit4->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"ShowText1","");
           Edit5->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"If1","");
           Edit6->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"ShowText2","");
           Edit7->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"If2","");
           Edit8->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"ShowText3","");
           Edit9->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"If3","");
           Memo1->Text = tmp->ReadString("Text "+IntToStr(ChosenText),"Note","");
        }
        Panel1->Font = FontDialog1->Font;

}
//---------------------------------------------------------------------------
void __fastcall TTextProperties::BitBtn2Click(TObject *Sender)
{
        //Name must be entered
        if(Edit1->Text=="")
        {
           ShowMessage("Enter Text Name");
           return;
        }
        IconText[ChosenText]->Caption = Edit1->Text;
        IconText[ChosenText]->Font->Name = FontDialog1->Font->Name;
        IconText[ChosenText]->Font->Size = FontDialog1->Font->Size;
        IconText[ChosenText]->Font->Style = FontDialog1->Font->Style;
        IconText[ChosenText]->Font->Color = FontDialog1->Font->Color;
        //save to tmp
        tmp->WriteString("Text "+IntToStr(ChosenText),"Name",Edit1->Text);
        tmp->WriteInteger("Text "+IntToStr(ChosenText),"Page",Form1->PageControl1->ActivePageIndex);
        tmp->WriteInteger("Text "+IntToStr(ChosenText),"PositionX",IconText[ChosenText]->Left);
        tmp->WriteInteger("Text "+IntToStr(ChosenText),"PositionY",IconText[ChosenText]->Top);
        tmp->WriteString("Text "+IntToStr(ChosenText),"OnMouseDown",Trim(Edit2->Text));
        tmp->WriteString("Text "+IntToStr(ChosenText),"OnMouseUp",Trim(Edit3->Text));
        //font
        tmp->WriteString("Text "+IntToStr(ChosenText),"FontName1",FontDialog1->Font->Name);
        tmp->WriteInteger("Text "+IntToStr(ChosenText),"FontSize1",FontDialog1->Font->Size);
        //font style
        String style = "";
        if(FontDialog1->Font->Style == FontDialog1->Font->Style <<fsBold)
           style = " bold";
        if(FontDialog1->Font->Style == FontDialog1->Font->Style <<fsItalic)
           style += " italic";
        if(FontDialog1->Font->Style == FontDialog1->Font->Style <<fsUnderline)
           style += " underline";
        if(FontDialog1->Font->Style == FontDialog1->Font->Style <<fsStrikeOut)
           style += " strikeout";
        tmp->WriteString("Text "+IntToStr(ChosenText),"FontStyle1",style);
        //font color
        tmp->WriteString("Text "+IntToStr(ChosenText),"FontColor1","0x"+IntToHex(FontDialog1->Font->Color,6));
        tmp->WriteString("Text "+IntToStr(ChosenText),"ShowText1",Edit4->Text);
        tmp->WriteString("Text "+IntToStr(ChosenText),"If1",Trim(Edit5->Text));
        tmp->WriteString("Text "+IntToStr(ChosenText),"ShowText2",Edit6->Text);
        tmp->WriteString("Text "+IntToStr(ChosenText),"If2",Trim(Edit7->Text));
        tmp->WriteString("Text "+IntToStr(ChosenText),"ShowText3",Edit8->Text);
        tmp->WriteString("Text "+IntToStr(ChosenText),"If3",Trim(Edit9->Text));
        //memo
        if(DialogCommand == "new")                                              //if new text add line
           Memo1->Lines->Add("");
        tmp->WriteString("Text "+IntToStr(ChosenText),"Note",Memo1->Text);
        //project modified
        ProjectModified(1);

        Close();
        ModalResult = mrOk;

}
//---------------------------------------------------------------------------
void __fastcall TTextProperties::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
        if (Key == VK_ESCAPE)
        {
           Close();
           ModalResult = mrCancel;
        }        
}
//---------------------------------------------------------------------------
void __fastcall TTextProperties::Button1Click(TObject *Sender)
{
        if (FontDialog1->Execute())
        {
           Panel1->Font = FontDialog1->Font;
        }
}
//---------------------------------------------------------------------------

