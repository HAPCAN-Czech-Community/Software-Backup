//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <IniFiles.hpp>
#include "imageprop.h"
#include "main.h"
#include "functions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TImageProperties *ImageProperties;

//extern
extern TIniFile *tmp;                //project tmp file
extern ChosenIcon;
extern TImage *IconImage[];
extern AnsiString DialogCommand;
extern AnsiString ProjectPath;
//local
AnsiString IconImg1="";
AnsiString IconImg2="";
AnsiString IconImg3="";
//---------------------------------------------------------------------------
__fastcall TImageProperties::TImageProperties(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TImageProperties::FormActivate(TObject *Sender)
{
        ImageProperties->Caption = "Icon "+IntToStr(ChosenIcon);               //form title
        IconImg1="";                                                            //default image1
        IconImg2="";                                                            //default image2
        if(DialogCommand == "new")                                              //new command
        {
           for(int i=1; i<=5; i++)                                              //clear edits
           {
              TEdit *EachEdit = dynamic_cast<TEdit *>(FindComponent("Edit" + IntToStr(i)));
              EachEdit->Text="";
           }
           Memo1->Text = "Note";
           Image1->Picture = Form1->warning->Picture;
           Image2->Picture = Form1->warning->Picture;
           Image3->Picture = Form1->warning->Picture;
        }
        if(DialogCommand == "edit")                                             //edit command
        {
           Edit1->Text = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"Name","");
           Edit2->Text = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"OnMouseDown","");
           Edit3->Text = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"OnMouseUp","");
           IconImg1 = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"ShowImage1","");
           Edit4->Text = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"If1","");
           IconImg2 = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"ShowImage2","");
           Edit5->Text = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"If2","");
           IconImg3 = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"ShowImage3","");
           Edit6->Text = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"If3","");
           Edit7->Text = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"HideIf","");
           Memo1->Text = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"Note","");
           try{                                                                 //image1
              if(IconImg1=="")
                 Image1->Picture = Form1->warning->Picture;
              else
                 Image1->Picture->LoadFromFile(ProjectPath+IconImg1); }
           catch(...){
              Image1->Picture = Form1->warning->Picture; }
           try{                                                                 //image2
              if(IconImg2=="")
                 Image2->Picture = Form1->warning->Picture;
              else
                 Image2->Picture->LoadFromFile(ProjectPath+IconImg2); }
           catch(...){
              Image2->Picture = Form1->warning->Picture; }
           try{                                                                 //image3
              if(IconImg3=="")
                 Image3->Picture = Form1->warning->Picture;
              else
                 Image3->Picture->LoadFromFile(ProjectPath+IconImg1); }
           catch(...){
              Image3->Picture = Form1->warning->Picture; }

        }
}
//---------------------------------------------------------------------------
void __fastcall TImageProperties::BitBtn2Click(TObject *Sender)
{
        //Name must be entered
        if(Edit1->Text=="")
        {
           ShowMessage("Enter Icon Name");
           return;
        }
        //show image
        if(IconImg1=="")      //no new icon
           IconImage[ChosenIcon]->Picture = Form1->chip->Picture;
        else                     //new icon was loaded
           IconImage[ChosenIcon]->Picture->LoadFromFile(ProjectPath+IconImg1);
        //save to tmp
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"Name",Edit1->Text);
        tmp->WriteInteger("Icon "+IntToStr(ChosenIcon),"Page",Form1->PageControl1->ActivePageIndex);
        tmp->WriteInteger("Icon "+IntToStr(ChosenIcon),"PositionX",IconImage[ChosenIcon]->Left);
        tmp->WriteInteger("Icon "+IntToStr(ChosenIcon),"PositionY",IconImage[ChosenIcon]->Top);
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"OnMouseDown",Trim(Edit2->Text));
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"OnMouseUp",Trim(Edit3->Text));
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"ShowImage1",ExtractRelativePath(ProjectPath,IconImg1));
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"If1",Trim(Edit4->Text));
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"ShowImage2",ExtractRelativePath(ProjectPath,IconImg2));
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"If2",Trim(Edit5->Text));
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"ShowImage3",ExtractRelativePath(ProjectPath,IconImg3));
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"If3",Trim(Edit6->Text));
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"HideIf",Trim(Edit7->Text));
        if(DialogCommand == "new")                                              //if new icon add line
           Memo1->Lines->Add("");
        tmp->WriteString("Icon "+IntToStr(ChosenIcon),"Note",Memo1->Text);
        //project modified
        ProjectModified(1);

        Close();
        ModalResult = mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TImageProperties::BitBtn3Click(TObject *Sender)
{
        if (OpenPictureDialog1->Execute())
        {
           Image1->Picture->LoadFromFile(OpenPictureDialog1->FileName);
           IconImg1 = ExtractRelativePath(ProjectPath,OpenPictureDialog1->FileName);
        }
}
//---------------------------------------------------------------------------
void __fastcall TImageProperties::BitBtn4Click(TObject *Sender)
{
        if (OpenPictureDialog1->Execute())
        {
           Image2->Picture->LoadFromFile(OpenPictureDialog1->FileName);
           IconImg2 = ExtractRelativePath(ProjectPath,OpenPictureDialog1->FileName);
        }
}
//---------------------------------------------------------------------------
void __fastcall TImageProperties::BitBtn5Click(TObject *Sender)
{
        if (OpenPictureDialog1->Execute())
        {
           Image3->Picture->LoadFromFile(OpenPictureDialog1->FileName);
           IconImg3 = ExtractRelativePath(ProjectPath,OpenPictureDialog1->FileName);
        }
}
//---------------------------------------------------------------------------
void __fastcall TImageProperties::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
        if (Key == VK_ESCAPE)
        {
           Close();
           ModalResult = mrCancel;
        }
}
//---------------------------------------------------------------------------





