//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <IniFiles.hpp>
#include "pageprop.h"
#include "main.h"
#include "functions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPageProperties *PageProperties;

//extern
extern TIniFile *tmp;                //project tmp file
extern TPanel *PagePanel[];
extern TImage *Background[];
extern AnsiString DialogCommand;
extern AnsiString ProjectPath;
//local
AnsiString BkgrPicture="";

//---------------------------------------------------------------------------
__fastcall TPageProperties::TPageProperties(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TPageProperties::FormActivate(TObject *Sender)
{
        PageProperties->Caption = "Page "+IntToStr(Form1->PageControl1->ActivePageIndex);               //form title

        if(DialogCommand == "new")                                              //new command
        {
           for(int i=1; i<=1; i++)                                              //clear edits
           {
              TEdit *EachEdit = dynamic_cast<TEdit *>(FindComponent("Edit" + IntToStr(i)));
              EachEdit->Text="";
           }
           Memo1->Text = "Note";
           Image1->Picture = 0;
           BkgrPicture = "";
           Panel1->Color = (TColor)0xA0A0A0;
           ColorDialog1->Color = Panel1->Color;
        }
        if(DialogCommand == "edit")                                             //edit command
        {
           Edit1->Text = tmp->ReadString("Page "+IntToStr(Form1->PageControl1->ActivePageIndex),"Name","");
           Panel1->Color = (TColor)StrToIntDef(tmp->ReadString("Page "+IntToStr(Form1->PageControl1->ActivePageIndex),"BackgroundColor","0xA0A0A0"),0xA0A0A0);
           ColorDialog1->Color = Panel1->Color;
           BkgrPicture = tmp->ReadString("Page "+IntToStr(Form1->PageControl1->ActivePageIndex),"BackgroundPicture","");
           Memo1->Text = tmp->ReadString("Page "+IntToStr(Form1->PageControl1->ActivePageIndex),"Note","");
           try{                                                                 //image1
              if(BkgrPicture=="")
                 Image1->Picture = 0;
              else
                 Image1->Picture->LoadFromFile(ProjectPath+BkgrPicture); }
           catch(...){
              Image1->Picture = 0; }
        }

}
//---------------------------------------------------------------------------
void __fastcall TPageProperties::BitBtn2Click(TObject *Sender)
{
        //Name must be entered
        if(Edit1->Text=="")
        {
           ShowMessage("Enter Page Name");
           return;
        }
        //show page
        Form1->PageControl1->Pages[Form1->PageControl1->ActivePageIndex]->Caption =
        "Page "+IntToStr(Form1->PageControl1->ActivePageIndex)+" - "+Edit1->Text;
        //show background picture
        if(BkgrPicture=="")      //no new picture
           Background[Form1->PageControl1->ActivePageIndex]->Picture = 0;
        else                     //new picture was loaded
           Background[Form1->PageControl1->ActivePageIndex]->Picture->LoadFromFile(ProjectPath+BkgrPicture);
        //show background color
        PagePanel[Form1->PageControl1->ActivePageIndex]->Color = Panel1->Color;
        //save to tmp
        tmp->WriteString("Page "+IntToStr(Form1->PageControl1->ActivePageIndex),"Name",Edit1->Text);
        tmp->WriteString("Page "+IntToStr(Form1->PageControl1->ActivePageIndex),"BackgroundColor","0x"+IntToHex(Panel1->Color,6));
        tmp->WriteString("Page "+IntToStr(Form1->PageControl1->ActivePageIndex),"BackgroundPicture",ExtractRelativePath(ProjectPath,BkgrPicture));
        if(DialogCommand == "new")                                              //if new icon add line
           Memo1->Lines->Add("");
        tmp->WriteString("Page "+IntToStr(Form1->PageControl1->ActivePageIndex),"Note",Memo1->Text);
        //project modified
        ProjectModified(1);

        Close();
        ModalResult = mrOk;

}
//---------------------------------------------------------------------------
void __fastcall TPageProperties::BitBtn3Click(TObject *Sender)
{
        if (OpenPictureDialog1->Execute())
        {
           Image1->Picture->LoadFromFile(OpenPictureDialog1->FileName);
           BkgrPicture = ExtractRelativePath(ProjectPath,OpenPictureDialog1->FileName);
        }
}
//---------------------------------------------------------------------------
void __fastcall TPageProperties::BitBtn4Click(TObject *Sender)
{
        Image1->Picture = 0;
        BkgrPicture = "";
}
//---------------------------------------------------------------------------
void __fastcall TPageProperties::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
        if (Key == VK_ESCAPE)
        {
           Close();
           ModalResult = mrCancel;
        }
}
//---------------------------------------------------------------------------

void __fastcall TPageProperties::BitBtn5Click(TObject *Sender)
{
        if (ColorDialog1->Execute())
           Panel1->Color = ColorDialog1->Color;

}
//---------------------------------------------------------------------------

