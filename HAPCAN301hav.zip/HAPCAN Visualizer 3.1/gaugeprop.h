//---------------------------------------------------------------------------

#ifndef levindpropH
#define levindpropH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include "CGAUGES.h"
#include "CSPIN.h"
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TGaugeProperties : public TForm
{
__published:	// IDE-managed Components
        TBitBtn *BitBtn2;
        TBitBtn *BitBtn1;
        TGroupBox *GroupBox1;
        TEdit *Edit1;
        TGroupBox *GroupBox2;
        TLabel *Label2;
        TLabel *Label3;
        TEdit *Edit2;
        TEdit *Edit3;
        TCGauge *CGauge1;
        TGroupBox *Display;
        TLabel *Label4;
        TLabel *Label5;
        TEdit *Edit4;
        TLabel *Label6;
        TGroupBox *GroupBox4;
        TMemo *Memo1;
        TColorDialog *ColorDialog1;
        TPanel *Panel1;
        TCGauge *CGauge2;
        TLabel *Label1;
        TLabel *Label7;
        TCSpinEdit *CSpinEdit1;
        TCSpinEdit *CSpinEdit2;
        TBitBtn *BitBtn4;
        TBitBtn *BitBtn3;
        TCheckBox *CheckBox1;
        TCheckBox *CheckBox2;
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall BitBtn2Click(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall BitBtn3Click(TObject *Sender);
        void __fastcall CSpinEdit1Change(TObject *Sender);
        void __fastcall CSpinEdit2Change(TObject *Sender);
        void __fastcall BitBtn4Click(TObject *Sender);
        void __fastcall CheckBox1Click(TObject *Sender);
        void __fastcall CheckBox2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TGaugeProperties(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGaugeProperties *GaugeProperties;
//---------------------------------------------------------------------------
#endif
