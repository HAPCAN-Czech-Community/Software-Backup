//---------------------------------------------------------------------------

#ifndef imagepropH
#define imagepropH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
//---------------------------------------------------------------------------
class TImageProperties : public TForm
{
__published:	// IDE-managed Components
        TOpenPictureDialog *OpenPictureDialog1;
        TGroupBox *GroupBox1;
        TEdit *Edit1;
        TGroupBox *GroupBox2;
        TLabel *Label2;
        TLabel *Label3;
        TEdit *Edit2;
        TEdit *Edit3;
        TImage *Image0;
        TGroupBox *GroupBox3;
        TLabel *Label4;
        TImage *Image1;
        TLabel *Label5;
        TImage *Image2;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label10;
        TBitBtn *BitBtn3;
        TEdit *Edit4;
        TEdit *Edit5;
        TEdit *Edit7;
        TBitBtn *BitBtn4;
        TBitBtn *BitBtn2;
        TBitBtn *BitBtn1;
        TGroupBox *GroupBox4;
        TMemo *Memo1;
        TImage *Image3;
        TEdit *Edit6;
        TLabel *Label9;
        TLabel *Label8;
        TBitBtn *BitBtn5;
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall BitBtn2Click(TObject *Sender);
        void __fastcall BitBtn3Click(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall BitBtn4Click(TObject *Sender);
        void __fastcall BitBtn5Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TImageProperties(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TImageProperties *ImageProperties;
//---------------------------------------------------------------------------
#endif
