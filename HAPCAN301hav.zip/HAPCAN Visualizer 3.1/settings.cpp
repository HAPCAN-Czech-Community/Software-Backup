//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <IniFiles.hpp>
#include "settings.h"
#include "main.h"
#include "functions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormSettings *FormSettings;

extern TIniFile *tmp;                //project tmp file
extern String  IP;                   //interface ip
extern String  Port;                 //interface port
extern int     TimeOut;              //response time

//---------------------------------------------------------------------------
__fastcall TFormSettings::TFormSettings(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormSettings::FormActivate(TObject *Sender)
{
        Edit1->Text = IP;
        Edit2->Text = Port;
        Edit3->Text = IntToStr(TimeOut);
}
//---------------------------------------------------------------------------
void __fastcall TFormSettings::BitBtn2Click(TObject *Sender)
{
        //can not be empty
        if(Edit1->Text == "" || Edit2->Text == "")
        {
           ShowMessage("Enter IP address and port number.");
           return;
        }
        //check port
        StrToIntDef(Edit2->Text,0);
        if(StrToInt(Edit2->Text) <= 0 || StrToInt(Edit2->Text)>65536)
        {
           ShowMessage("Port number must be between 1 - 65536");
           return;
        }
        //check timeout
        StrToIntDef(Edit3->Text,0);
        if(StrToInt(Edit3->Text) <= 0 || StrToInt(Edit3->Text)>2000)
        {
           ShowMessage("Timeout must be between 1 - 2000 ms");
           return;
        }
        //save if changed
        if(Edit1->Text != tmp->ReadString ( "Settings", "IP", "")
           || Edit2->Text != tmp->ReadString ( "Settings", "Port", "")
           || Edit3->Text != tmp->ReadString ( "Settings", "TimeOut", ""))
        {
           //save to tmp
           tmp->WriteString("Settings","IP",Edit1->Text);
           IP = Edit1->Text;
           tmp->WriteString("Settings","Port",Edit2->Text);
           Port = Edit2->Text;
           tmp->WriteString("Settings","TimeOut",Edit3->Text);
           TimeOut = StrToIntDef(Edit3->Text,50);
           ProjectModified(1);
        }

        Close();
        ModalResult = mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TFormSettings::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
        if (Key == VK_ESCAPE)
        {
           Close();
           ModalResult = mrCancel;
        }
}
//---------------------------------------------------------------------------

