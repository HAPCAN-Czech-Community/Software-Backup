//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "rgb.h"
#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TWin_RGB *Win_RGB;

//local
String cmd;                                   //local commnad variable
int             SendRGB_Thread;               //thread
unsigned int    SendRGB_ThreadID;
BYTE ID1_Node;                                //IDs of nodes in RGB function
BYTE ID1_Group;
BYTE ID2_Node;
BYTE ID2_Group;
BYTE ID3_Node;
BYTE ID3_Group;
BYTE RGB1;                                    //chosen color
BYTE RGB2;
//global
extern unsigned char PcNode;                  //PC ID - node
extern unsigned char PcGroup;                 //PC ID - group
extern String        cmdRGB;                  //string of RGB(x,y) function
extern int           TimeOut;                 //response time


//---------------------------------------------------------------------------
__fastcall TWin_RGB::TWin_RGB(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TWin_RGB::FormActivate(TObject *Sender)
{
     //ID1
        String ID = cmdRGB;
        ID1_Node = ID.Delete(1,ID.Pos("(")).Delete(ID.Pos(","),50).ToIntDef(0);
        ID = cmdRGB;
        ID1_Group = ID.Delete(1,ID.Pos(",")).Delete(ID.Pos(")"),50).ToIntDef(0);
     //ID2
        ID = cmdRGB;
        ID.Delete(1,ID.Pos(")"));                                  //remove RGB(x1,y1)
        ID2_Node = ID.Delete(1,ID.Pos("(")).Delete(ID.Pos(","),50).ToIntDef(0);
        ID = cmdRGB;
        ID2_Group = ID.Delete(1,ID.Pos(",")).Delete(ID.Pos(")"),50).ToIntDef(0);
     //ID3
        ID = cmdRGB;
        ID.Delete(1,ID.Pos(")")).Delete(1,ID.Pos(")"));           //remove RGB(x1,y1);RGB(x2,y2)
        ID3_Node = ID.Delete(1,ID.Pos("(")).Delete(ID.Pos(","),50).ToIntDef(0);
        ID = cmdRGB;
        ID3_Group = ID.Delete(1,ID.Pos(",")).Delete(ID.Pos(")"),50).ToIntDef(0);
}
//---------------------------------------------------------------------------
void __fastcall TWin_RGB::PanelCancelClick(TObject *Sender)
{
        Close();
}
//---------------------------------------------------------------------------
int __fastcall SendRGB_Function(Pointer Parameter)
{
        if(ID1_Node!=0 && ID1_Group!=0)
        SendToBus(0x10,0xA0,PcNode,PcGroup,0xFF,0xFF,ID1_Node,ID1_Group,0xFF,0x1C,RGB1,RGB2);
        Sleep(TimeOut);
        if(ID2_Node!=0 && ID2_Group!=0)
        SendToBus(0x10,0xA0,PcNode,PcGroup,0xFF,0xFF,ID2_Node,ID2_Group,0xFF,0x1C,RGB1,RGB2);
        Sleep(TimeOut);
        if(ID3_Node!=0 && ID3_Group!=0)
        SendToBus(0x10,0xA0,PcNode,PcGroup,0xFF,0xFF,ID3_Node,ID3_Group,0xFF,0x1C,RGB1,RGB2);
        Sleep(TimeOut);

        Win_RGB->Image1->Enabled = true;
        SuspendThread((HANDLE)SendRGB_Thread);
        CloseHandle((HANDLE)SendRGB_Thread);
        return true;
}
//---------------------------------------------------------------------------
void __fastcall TWin_RGB::Image1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
        Image1->Enabled = false;
        TColor LEDRGB = Image1->Canvas->Pixels[X][Y];
        RGB1=(GetRValue(LEDRGB)/8)*8+(GetGValue(LEDRGB)/8)/4;        //5bits of R + 3bits of G
        RGB2=(GetGValue(LEDRGB)/8)*64+(GetBValue(LEDRGB)/8)*2;       //2bits of G + 5bits of B

        SendRGB_Thread = BeginThread(NULL,0,SendRGB_Function,NULL,0,SendRGB_ThreadID);
}
//---------------------------------------------------------------------------

void __fastcall TWin_RGB::Image4Click(TObject *Sender)
{
        Close();        
}
//---------------------------------------------------------------------------

void __fastcall TWin_RGB::Label4Click(TObject *Sender)
{
        Close();        
}
//---------------------------------------------------------------------------

