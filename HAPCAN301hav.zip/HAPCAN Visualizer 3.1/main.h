//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <ScktComp.hpp>
#include <Graphics.hpp>
#include <jpeg.hpp>
#include "CGAUGES.h"
#include <ImgList.hpp>
#include <Buttons.hpp>
#include <ToolWin.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TClientSocket *ClientSocket1;
        TMainMenu *MainMenu1;
        TMenuItem *File1;
        TMenuItem *Open1;
        TMenuItem *SaveProject;
        TMenuItem *CloseProject;
        TMenuItem *Vizualize1;
        TMenuItem *Start1;
        TMenuItem *Help1;
        TMenuItem *Insert1;
        TMenuItem *InsertIcon;
        TImageList *ImageList1;
        TPopupMenu *ImageMenu;
        TMenuItem *DeleteImage;
        TImage *chip;
        TStatusBar *StatusBar1;
        TMenuItem *empty1;
        TMenuItem *N1;
        TMenuItem *EditImage;
        TMenuItem *New1;
        TSaveDialog *SaveDialog1;
        TOpenDialog *OpenDialog1;
        TMenuItem *InsertPage1;
        TOpenPictureDialog *OpenPictureDialog1;
        TMemo *Memo1;
        TMenuItem *SaveAs1;
        TMenuItem *Exit;
        TMenuItem *N3;
        TImage *warning;
        TMenuItem *Settings1;
        TMenuItem *About1;
        TPopupMenu *TextMenu;
        TMenuItem *empty2;
        TMenuItem *N2;
        TMenuItem *EditText;
        TMenuItem *DeleteText;
        TMenuItem *Text1;
        TMenuItem *Gauge1;
        TPopupMenu *GaugeMenu;
        TMenuItem *MenuItem1;
        TMenuItem *MenuItem2;
        TMenuItem *EditGauge;
        TMenuItem *DeleteGauge;
        TTimer *Timer1;
        TPageControl *PageControl1;
        TPopupMenu *PageMenu;
        TMenuItem *MenuItem3;
        TMenuItem *MenuItem4;
        TMenuItem *EditPage;
        TMenuItem *DeletePage;
        TImage *logo1on;
        TImage *logo1;
        TLabel *logo2;
        TLabel *logo3;
        TImage *logo1off;
        TTimer *Timer2;
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall ClientSocket1Connect(TObject *Sender,
          TCustomWinSocket *Socket);
        void __fastcall ClientSocket1Error(TObject *Sender,
          TCustomWinSocket *Socket, TErrorEvent ErrorEvent,
          int &ErrorCode);
        void __fastcall ClientSocket1Read(TObject *Sender,
          TCustomWinSocket *Socket);
        void __fastcall Start1Click(TObject *Sender);
        void __fastcall InsertIconClick(TObject *Sender);
        void __fastcall DeleteImageClick(TObject *Sender);
        void __fastcall EditImageClick(TObject *Sender);
        void __fastcall CloseProjectClick(TObject *Sender);
        void __fastcall New1Click(TObject *Sender);
        void __fastcall Open1Click(TObject *Sender);
        void __fastcall InsertPage1Click(TObject *Sender);
        void __fastcall SaveProjectClick(TObject *Sender);
        void __fastcall SaveAs1Click(TObject *Sender);
        void __fastcall ExitClick(TObject *Sender);
        void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
        void __fastcall Settings1Click(TObject *Sender);
        void __fastcall logo1Click(TObject *Sender);
        void __fastcall Text1Click(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall DeleteTextClick(TObject *Sender);
        void __fastcall EditTextClick(TObject *Sender);
        void __fastcall About1Click(TObject *Sender);
        void __fastcall DeleteGaugeClick(TObject *Sender);
        void __fastcall EditGaugeClick(TObject *Sender);
        void __fastcall Gauge1Click(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall PageControl1Change(TObject *Sender);
        void __fastcall EditPageClick(TObject *Sender);
        void __fastcall DeletePageClick(TObject *Sender);
        void __fastcall PageControl1MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FormResize(TObject *Sender);
        void __fastcall Timer2Timer(TObject *Sender);
private:	// User declarations
        void __fastcall ImageMouseDown(TObject *Sender, TMouseButton, TShiftState, int, int);
        void __fastcall ImageMouseMove(TObject *Sender, TShiftState, int, int);
        void __fastcall ImageMouseUp(TObject *Sender, TMouseButton, TShiftState, int, int);
        void __fastcall TextMouseDown(TObject *Sender, TMouseButton, TShiftState, int, int);
        void __fastcall TextMouseMove(TObject *Sender, TShiftState, int, int);
        void __fastcall TextMouseUp(TObject *Sender, TMouseButton, TShiftState, int, int);
        void __fastcall GaugeMouseDown(TObject *Sender, TMouseButton, TShiftState, int, int);
        void __fastcall GaugeMouseMove(TObject *Sender, TShiftState, int, int);
        void __fastcall GaugeMouseUp(TObject *Sender, TMouseButton, TShiftState, int, int);
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
        void __fastcall ReadTmpFile(void);
        void __fastcall SendToBus(unsigned char a, unsigned char b, unsigned char c,
                            unsigned char d, unsigned char e, unsigned char f,
                            unsigned char g, unsigned char h, unsigned char i,
                            unsigned char j, unsigned char k, unsigned char l);
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
