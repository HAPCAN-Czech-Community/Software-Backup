//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#include <math.h>
#pragma hdrstop

#include <IniFiles.hpp>
#include "main.h"
#include "stdlib.h"
#include "imageprop.h"
#include "functions.h"
#include "settings.h"
#include "textprop.h"
#include "about.h"
#include "gaugeprop.h"
#include "Math.hpp"
#include "pageprop.h"
#include "popup.h"
#include "menu.h"
#include "rgb.h"
//---------------------------------------------------------------------------
#define MaxPageNo 50
#define MaxImageNo 300
#define MaxTextNo 300
#define MaxGaugeNo 100
//---------------------------------------------------------------------------
TForm1 *Form1;
#pragma package(smart_init)
#pragma link "CGAUGES"
#pragma resource "*.dfm"

//settings
String  IP="";                   //interface ip
String  Port="";                 //interface port
int     TimeOut=50;              //response time

//receive buffers
unsigned char BufferIP[1500];    //TCPIP receive buffer
unsigned char BufferIPRem[15];   //Remaining bytes of received TCPIP buffer, that were not proceed
int remaining = 0;               //Number of remaing bytes
unsigned char BufferIn[12];      //receive buffer without start, stop and checksum bytes

//other
int FreezeTime = 400;            //Main form disable time after icon press
String NodeDataBase;             //Database for nodes when asking for status
String NodeID;                   //node ID - string (x,y) written into NodeDataDase
unsigned char PcNode=0xF8;       //PC ID - node
unsigned char PcGroup=0xF8;      //PC ID - group
TIniFile *tmp;                   //project tmp file
bool runs = false;               //flag when visualization runs
AnsiString TmpString;            //string read from tmp file
char *TmpChar = new char[36];    //char buffer of read from tmp file message
unsigned char TmpHex[12];        //hex buffer of read from tmp file message and converted to hex
AnsiString ProjectPath;          //project path
AnsiString ProjectFile;          //project file including path
bool ProjectModifiedFlag = 0;
int ChosenIcon;
int ChosenText;
int ChosenGauge;
AnsiString DialogCommand = "";
int             Status_Thread;
unsigned int    Status_ThreadID;
//drag and drop variables
bool MouseIsDown = false;
int ObjectDownX, ObjectDownY;
bool ObjectIsChosen = false;

TImage *Background[MaxPageNo] = {0};       //sets up an array of background images
TPanel *PagePanel[MaxPageNo] = {0};        //sets up an array of page panels
TImage *IconImage[MaxImageNo] = {0};       //sets up an array of images for icons
TLabel *IconText[MaxTextNo] = {0};         //sets up an array of texts for icons
TPanel *IconGauge[MaxGaugeNo] = {0};       //sets up an array of panels for icons
TCGauge *gauge[MaxGaugeNo] = {0};          //sets up an array of gauges on panels for icons

//global antileak memory variables
String  command;                        //commnad send when icon is pressed
String  cmdPAGE;                        //string of PAGE(x) function
String  cmdRGB;                         //string of RGB(x,y) function
String  cmdAPP;                         //string of APP(application or file eg. url) function

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
        //PAGE
        PageControl1->Align = alClient;
        PageControl1->Visible = false;
        for (int i = 0; i<MaxPageNo; i++)
        {
           TTabSheet *pPage = new TTabSheet(PageControl1);
           pPage->PageControl = PageControl1;
           pPage->Caption = AnsiString("Page") + IntToStr(i);
           pPage->Name = pPage->Caption;
           pPage->ImageIndex = 20;
           pPage->TabVisible = false;
           //page panel color
           PagePanel[i] = new TPanel(Form1);
           PagePanel[i]->Parent = PageControl1->Pages[i];
           PagePanel[i]->Tag = i;
           PagePanel[i]->Align = alClient;
           PagePanel[i]->Caption = "";
           PagePanel[i]->BevelInner = bvNone;
           PagePanel[i]->BevelOuter = bvNone;
           PagePanel[i]->BorderStyle = bsNone;
           PagePanel[i]->Color = (TColor)0xA0A0A0;
           //page background
           Background[i] = new TImage(Form1);
           Background[i]->Parent = PagePanel[i];
           Background[i]->Tag = i;
           Background[i]->Align = alClient;

        }
        //IMAGE
        for (int i=0; i<MaxImageNo; i++)
        {
           IconImage[i] = new TImage(Form1);
	   IconImage[i]->OnMouseDown = Form1->ImageMouseDown;
	   IconImage[i]->OnMouseUp = Form1->ImageMouseUp;
	   IconImage[i]->OnMouseMove = Form1->ImageMouseMove;
           IconImage[i]->AutoSize= true;
           IconImage[i]->Transparent = true;
           IconImage[i]->Tag = i;
           IconImage[i]->BringToFront();
           IconImage[i]->Visible = false;
           IconImage[i]->ShowHint=1;
        }
        //TEXT
        for (int i=0; i<MaxTextNo; i++)
        {
           IconText[i] = new TLabel(Form1);
	   IconText[i]->OnMouseDown = Form1->TextMouseDown;
	   IconText[i]->OnMouseUp = Form1->TextMouseUp;
	   IconText[i]->OnMouseMove = Form1->TextMouseMove;
           IconText[i]->Transparent = true;
           IconText[i]->Tag = i;
           IconText[i]->BringToFront();
           IconText[i]->Visible = false;
           IconText[i]->ShowHint=1;
        }
        //GAUGE
        for (int i=0; i<MaxGaugeNo; i++)
        {
           IconGauge[i] = new TPanel(Form1);
           IconGauge[i]->BevelInner = bvNone;
           IconGauge[i]->BevelOuter = bvNone;
    	   IconGauge[i]->OnMouseDown = Form1->GaugeMouseDown;
    	   IconGauge[i]->OnMouseUp = Form1->GaugeMouseUp;
    	   IconGauge[i]->OnMouseMove = Form1->GaugeMouseMove;
           IconGauge[i]->Height = 33;
           IconGauge[i]->Width = 20;
           IconGauge[i]->BringToFront();
           IconGauge[i]->Visible = false;
           IconGauge[i]->ShowHint=1;
           IconGauge[i]->Tag = i;
           gauge[i] = new TCGauge(IconGauge[i]);
           gauge[i]->Parent = IconGauge[i];
           gauge[i]->Align = alClient;
           gauge[i]->Kind = gkVerticalBar;
           gauge[i]->Progress = 66;
           gauge[i]->ForeColor = clGreen;
           gauge[i]->MaxValue = 255;
           gauge[i]->MinValue = 0;
           gauge[i]->Font->Name = "MS Serif";
           gauge[i]->Font->Size = 7;
           gauge[i]->Enabled = false;
           gauge[i]->Tag = i;
        }
}
//------------------------------------------------------------------------------
//      FUNCTIONS
//------------------------------------------------------------------------------
int __fastcall CharIsHex(char character)    //char is converted to hex with rule X = Xh
{
        byte hexadecimal = -1;
        if (character == 48)    //"0"
        hexadecimal = 0x00;
        if (character == 49)    //"1"
        hexadecimal = 0x01;
        if (character == 50)    //"2"
        hexadecimal = 0x02;
        if (character == 51)    //"3"
        hexadecimal = 0x03;
        if (character == 52)    //"4"
        hexadecimal = 0x04;
        if (character == 53)    //"5"
        hexadecimal = 0x05;
        if (character == 54)    //"6"
        hexadecimal = 0x06;
        if (character == 55)    //"7"
        hexadecimal = 0x07;
        if (character == 56)    //"8"
        hexadecimal = 0x08;
        if (character == 57)    //"9"
        hexadecimal = 0x09;
        if (character == 65 || character == 97)    //"A","a"
        hexadecimal = 0x0A;
        if (character == 66 || character == 98)    //"B","b"
        hexadecimal = 0x0B;
        if (character == 67 || character == 99)    //"C","c"
        hexadecimal = 0x0C;
        if (character == 68 || character == 100)    //"D","d"
        hexadecimal = 0x0D;
        if (character == 69 || character == 101)    //"E","e"
        hexadecimal = 0x0E;
        if (character == 70 || character == 102)    //"F","f"
        hexadecimal = 0x0F;
        return hexadecimal;
}
//---------------------------------------------------------------------------
void __fastcall ReadTmpFile(void)
{
        if(tmp)
           delete tmp;
           tmp = new TIniFile(ChangeFileExt(ProjectFile, ".tmp" ));
        //settings
        IP = tmp->ReadString("Settings", "IP", "");
        Port = tmp->ReadString("Settings", "Port", "");
        TimeOut = StrToIntDef(tmp->ReadString("Settings", "TimeOut", "50"),50);
        //page
        Form1->PageControl1->Pages[0]->TabVisible = true;       //first page always
        for(int i=0; i<MaxPageNo; i++)
        {
           if(tmp->SectionExists("Page "+IntToStr(i)))
           {
              Form1->PageControl1->Pages[i]->TabVisible = true;   //show page
              Form1->PageControl1->Pages[i]->Caption = "Page "+IntToStr(i)+" - "
              +tmp->ReadString("Page "+IntToStr(i),"Name","");  //page name

              //background color
              PagePanel[i]->Color = (TColor)StrToIntDef(tmp->ReadString("Page "+IntToStr(i),"BackgroundColor","0xA0A0A0"),0xA0A0A0);
              //backround picture
              try{
                 String BkgrPicture  = tmp->ReadString("Page "+IntToStr(i),"BackgroundPicture","");
                 if(BkgrPicture=="")
                    Background[i]->Picture=0;
                 else
                    Background[i]->Picture->LoadFromFile(ProjectPath+BkgrPicture); }
              catch(...){
                 Background[i]->Picture=0; }
           }
        }
        //icons
        for(int i=0; i<MaxImageNo; i++)
        {
           if(tmp->ReadString(("Icon "+IntToStr(i)),"Name","")!="")
           {
              Form1->PageControl1->Pages[tmp->ReadInteger(("Icon "+IntToStr(i)),"Page",0)]->TabVisible = true;   //show page
              IconImage[i]->Parent = PagePanel[tmp->ReadInteger(("Icon "+IntToStr(i)),"Page",0)];      //page
              IconImage[i]->Left = tmp->ReadInteger(("Icon "+IntToStr(i)),"PositionX",50);      //position x
              IconImage[i]->Top = tmp->ReadInteger(("Icon "+IntToStr(i)),"PositionY",50);       //position y
              try{
                 String IconImg = tmp->ReadString(("Icon "+IntToStr(i)),"ShowImage1","");            //icon image
                 if(IconImg=="")
                    IconImage[i]->Picture = Form1->chip->Picture;
                 else
                    IconImage[i]->Picture->LoadFromFile(ProjectPath+IconImg); }
              catch(...){
                 //IconImage[i]->Picture = Form1->chip->Picture;
                 }
              IconImage[i]->Visible = true;                                                     //make visible
           }
        }
        //gauge
        for(int i=0; i<MaxGaugeNo; i++)
        {
           if(tmp->ReadString(("gauge "+IntToStr(i)),"Name","")!="")
           {
              Form1->PageControl1->Pages[tmp->ReadInteger(("Gauge "+IntToStr(i)),"Page",0)]->TabVisible = true;   //show page
              IconGauge[i]->Parent = PagePanel[tmp->ReadInteger(("Gauge "+IntToStr(i)),"Page",0)];          //page
              IconGauge[i]->Left = tmp->ReadInteger(("Gauge "+IntToStr(i)),"PositionX",50);      //position x
              IconGauge[i]->Top = tmp->ReadInteger(("Gauge "+IntToStr(i)),"PositionY",50);       //position y
              IconGauge[i]->Width = tmp->ReadInteger("Gauge "+IntToStr(i),"Width",20);
              IconGauge[i]->Height = tmp->ReadInteger("Gauge "+IntToStr(i),"Height",30);
           //color
              gauge[i]->ForeColor = (TColor)StrToIntDef(tmp->ReadString("Gauge "+IntToStr(i),"ForeColor","0x008000"),0x008000);
              gauge[i]->BackColor = (TColor)StrToIntDef(tmp->ReadString("Gauge "+IntToStr(i),"BackColor","0xFFFFFF"),0xFFFFFF);
              IconGauge[i]->Visible = true;                                                      //make visible
           }
           //text
           gauge[i]->ShowText = tmp->ReadBool("Gauge "+IntToStr(i),"ShowText",true);
           //border
           if(tmp->ReadBool("Gauge "+IntToStr(i),"ShowBorder",true)==true)
              gauge[i]->BorderStyle = bsSingle;
           else
              gauge[i]->BorderStyle = bsNone;
        }
        //text
        for(int i=0; i<MaxTextNo; i++)
        {
           if(tmp->ReadString(("Text "+IntToStr(i)),"Name","")!="")
           {
              Form1->PageControl1->Pages[tmp->ReadInteger(("Text "+IntToStr(i)),"Page",0)]->TabVisible = true;   //show page
              IconText[i]->Caption = tmp->ReadString(("Text "+IntToStr(i)),"Name","");         //name
              IconText[i]->Parent = PagePanel[tmp->ReadInteger(("Text "+IntToStr(i)),"Page",0)];          //page
              IconText[i]->Left = tmp->ReadInteger(("Text "+IntToStr(i)),"PositionX",50);      //position x
              IconText[i]->Top = tmp->ReadInteger(("Text "+IntToStr(i)),"PositionY",50);       //position y
              IconText[i]->Font->Name = tmp->ReadString(("Text "+IntToStr(i)),"FontName1","MS Sans Serif");   //Font
              IconText[i]->Font->Size = tmp->ReadInteger(("Text "+IntToStr(i)),"FontSize1",8);
              IconText[i]->Font->Style = IconText[i]->Font->Style.Clear();
              if((tmp->ReadString(("Text "+IntToStr(i)),"FontStyle1","").Pos("bold"))!=0)
                 IconText[i]->Font->Style = IconText[i]->Font->Style << fsBold;
              if((tmp->ReadString(("Text "+IntToStr(i)),"FontStyle1","").Pos("italic"))!=0)
                 IconText[i]->Font->Style = IconText[i]->Font->Style << fsItalic;
              if((tmp->ReadString(("Text "+IntToStr(i)),"FontStyle1","").Pos("underline"))!=0)
                 IconText[i]->Font->Style = IconText[i]->Font->Style << fsUnderline;
              if((tmp->ReadString(("Text "+IntToStr(i)),"FontStyle1","").Pos("strikeout"))!=0)
                 IconText[i]->Font->Style = IconText[i]->Font->Style << fsStrikeOut;
              IconText[i]->Font->Color = (TColor)StrToIntDef(tmp->ReadString(("Text "+IntToStr(i)),"FontColor1","0x000000"),0x000000);

              IconText[i]->Refresh();
              IconText[i]->Visible = true;                                                     //make visible
           }
        }
        Form1->PageControl1->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall ReadHexFromTmp(AnsiString section, AnsiString name)
{
        String Message = tmp->ReadString(section,name,"");                    //get message from tmp
        TmpString = Message;
        for(int i=0; i<Message.Length(); i++)                                 //remove spaces
        {
           if(Message.SubString(i,1)==" ")
           {
              Message.Delete(i,1);
              i=i-1;       //if deleted check the same position
           }
        }
        TmpChar = Message.c_str();                                         //buffer of chars
        //convert to hex
        if(Message.Length()==24)                                           //mesage without operators
        {
           for(int i=0; i<12; i++)
           TmpHex[i] = CharIsHex(TmpChar[2*i])*16+CharIsHex(TmpChar[2*i+1]);
        }
        if(Message.Length()==36)                                           //mesage with operators
        {
           for(int i=0; i<12; i++)                                                 //convert to hex if string with operators
           TmpHex[i] = CharIsHex(TmpChar[3*i+1])*16+CharIsHex(TmpChar[3*i+2]);
        }
}
//---------------------------------------------------------------------------
void __fastcall SendToBus(unsigned char a, unsigned char b, unsigned char c,
                            unsigned char d, unsigned char e, unsigned char f,
                            unsigned char g, unsigned char h, unsigned char i,
                            unsigned char j, unsigned char k, unsigned char l)
{
        unsigned char Buffer[15];
        Buffer[0]=0xAA,
        Buffer[1]=a, Buffer[2]=b, Buffer[3]=c, Buffer[4]=d, Buffer[5]=e, Buffer[6]=f,
        Buffer[7]=g, Buffer[8]=h, Buffer[9]=i, Buffer[10]=j, Buffer[11]=k, Buffer[12]=l;
        Buffer[13]=0x00;
        for(int i=1; i<13; i++)
          Buffer[13] += Buffer[i];
        Buffer[14]=0xA5;
        if(Form1->ClientSocket1->Active)
           Form1->ClientSocket1->Socket->SendBuf(Buffer,15);
}
//---------------------------------------------------------------------------
bool __fastcall CompareMessages(unsigned char Buf1[12],char Buf2[12])
{
        Buf1[1]=(Buf1[1]&0xFE);                 //response = normal message
        for(int i=0; i<12; i++)
        {  //"x","?","=","!"                                     //"x" - any
           if(Buf2[3*i]==120||Buf2[3*i]==63||Buf2[3*i]==61||Buf2[3*i]==33);
           else
              return false;
           //---------------
           if(Buf2[3*i]==61)                                    //"=" - equal
           {
              if(Buf1[i]==((CharIsHex(Buf2[3*i+1])*16)+CharIsHex(Buf2[3*i+2])));
              else
                 return false;
           }
           //---------------
           if(Buf2[3*i]==33)                                    //"!" - not equal
           {
              if(Buf1[i]!=((CharIsHex(Buf2[3*i+1])*16)+CharIsHex(Buf2[3*i+2])));
              else
                 return false;
           }
        }
        return true;

}
//---------------------------------------------------------------------------
bool __fastcall Function_PAGE(AnsiString object, int chosen, AnsiString event)
{
        if(tmp->ReadString(object+" "+IntToStr(chosen),event,"").Delete(5,5) == "PAGE")
        {
           cmdPAGE = tmp->ReadString(object+" "+IntToStr(chosen),event,"");
           if(cmdPAGE.Delete(1,cmdPAGE.Pos("(")).Delete(cmdPAGE.Pos(")"),1).ToIntDef(MaxPageNo+1)<MaxPageNo)
           {
              Form1->PageControl1->Pages[cmdPAGE.Delete(1,cmdPAGE.Pos("(")).Delete(cmdPAGE.Pos(")"),1).ToIntDef(0)]->Show();
              Form1->PageControl1Change(Form1->PageControl1->ActivePage);     //bring to front logo
           }
           return true;
        }
        else
           return false;
}
//---------------------------------------------------------------------------
bool __fastcall Function_RGB(AnsiString object, int chosen, AnsiString event)
{
        if(tmp->ReadString(object+" "+IntToStr(chosen),event,"").Delete(4,50) == "RGB")
        {
           cmdRGB = tmp->ReadString(object+" "+IntToStr(chosen),event,"");
           Win_RGB->ShowModal();
           return true;
        }
        else
           return false;
}
//---------------------------------------------------------------------------
bool __fastcall Function_APP(AnsiString object, int chosen, AnsiString event)
{
        if(tmp->ReadString(object+" "+IntToStr(chosen),event,"").Delete(4,50) == "APP")
        {
           cmdAPP = tmp->ReadString(object+" "+IntToStr(chosen),event,"");
           ShellExecute( 0, "open", cmdAPP.Delete(1,cmdAPP.Pos("(")).Delete(cmdAPP.Pos(")"),1).c_str(), NULL, NULL, SW_NORMAL );
           return true;
        }
        else
           return false;
}
//------------------------------------------------------------------------------
//      IMAGE
//---------------------------------------------------------------------------
void __fastcall RunImage(AnsiString event)
{
        //OnMouseDown or OnMouseUp
        if(event == "OnMouseDown" || event == "OnMouseUp")
        {
           //page command
           if(Function_PAGE("Icon",ChosenIcon,event));

           //rgb window command
           else if(Function_RGB("Icon",ChosenIcon,event));

           //web window command
           else if(Function_APP("Icon",ChosenIcon,event));

           //string commnad
           else
           {
              //send command
              ReadHexFromTmp(("Icon "+IntToStr(ChosenIcon)),event);    //get message from tmp
              if(TmpString != "")                                      //empty string?
                 SendToBus(TmpHex[0],TmpHex[1],TmpHex[2],TmpHex[3],TmpHex[4],TmpHex[5],TmpHex[6],TmpHex[7],TmpHex[8],TmpHex[9],TmpHex[10],TmpHex[11]);
              if(event == "OnMouseUp")
              {
                 Form1->Timer2->Enabled = true;                        //count main form disable time
                 Form1->Enabled = false;
              }
           }
        }
}
//---------------------------------------------------------------------------
void __fastcall StatusImage(void)
{
        for(int i=0; i<MaxImageNo; i++)                                         //check all images
        {
           if(IconImage[i]->Parent == PagePanel[Form1->PageControl1->ActivePageIndex])  //look only for icons on active page
           {
           //ShowImage1
              ReadHexFromTmp("Icon "+IntToStr(i),"If1");                       //read from file show1if value
              if(CompareMessages(BufferIn,TmpChar)==true)
              {
                 ReadHexFromTmp("Icon "+IntToStr(i),"ShowImage1");                   //read icon path
                 try{                                                                 //image1
                    if(TmpString=="")
                       IconImage[i]->Picture = Form1->warning->Picture;
                    else
                       IconImage[i]->Picture->LoadFromFile(ProjectPath+TmpString); }
                 catch(...){
                    IconImage[i]->Picture = Form1->warning->Picture; }

                 IconImage[i]->Visible = true;
              }
           //ShowImage2
              ReadHexFromTmp("Icon "+IntToStr(i),"If2");                       //read from file show2if value
              if(CompareMessages(BufferIn,TmpChar)==true)
              {
                 ReadHexFromTmp("Icon "+IntToStr(i),"ShowImage2");                   //read icon path
                 try{                                                                 //image1
                    if(TmpString=="")
                       IconImage[i]->Picture = Form1->warning->Picture;
                    else
                       IconImage[i]->Picture->LoadFromFile(ProjectPath+TmpString); }
                 catch(...){
                    IconImage[i]->Picture = Form1->warning->Picture; }

                 IconImage[i]->Visible = true;
              }
           //ShowImage3
              ReadHexFromTmp("Icon "+IntToStr(i),"If3");                       //read from file show2if value
              if(CompareMessages(BufferIn,TmpChar)==true)
              {
                 ReadHexFromTmp("Icon "+IntToStr(i),"ShowImage3");                   //read icon path
                 try{                                                                 //image1
                    if(TmpString=="")
                       IconImage[i]->Picture = Form1->warning->Picture;
                    else
                       IconImage[i]->Picture->LoadFromFile(ProjectPath+TmpString); }
                 catch(...){
                    IconImage[i]->Picture = Form1->warning->Picture; }

                 IconImage[i]->Visible = true;
              }
           //HideIf
              ReadHexFromTmp("Icon "+IntToStr(i),"HideIf");                        //read from file hideif value
              if(CompareMessages(BufferIn,TmpChar)==true)
                 IconImage[i]->Visible = false;
           }
        }
}
//---------------------------------------------------------- On image Mouse Down
void __fastcall TForm1::ImageMouseDown(TObject *Sender,
	  TMouseButton Button, TShiftState Shift, int X, int Y)
{
        //image where the mouse was downed and parameters
        TImage *image = dynamic_cast<TImage*>(Sender);
        ChosenIcon = image->Tag;

        //if visualization runs
        if(runs)
        {
           if(Button == mbLeft)
           RunImage("OnMouseDown");
           return;
        }
        ObjectDownX = X;
        ObjectDownY = Y;
        MouseIsDown = true;

        if (Button == mbLeft)
	   ObjectIsChosen = true;
        if (Button == mbRight)
        {
           ImageMenu->Items->Items[0]->Caption = "Icon "+IntToStr(image->Tag);
           ImageMenu->Items->Items[0]->Enabled = 0;
           ImageMenu->Popup(X+Form1->Left+IconImage[ChosenIcon]->Left+5,Y+Form1->Top+IconImage[ChosenIcon]->Top+50);
        }
}
//---------------------------------------------------------- On image Mouse Move
void __fastcall TForm1::ImageMouseMove(TObject *Sender,
	  TShiftState Shift, int X, int Y)
{
        TImage *image = dynamic_cast<TImage*>(Sender);
        ChosenIcon = image->Tag;

        if (ObjectIsChosen)             //drag
        {
	   //this drags the image
	   image->Left = image->Left + X - ObjectDownX;
	   image->Top = image->Top + Y - ObjectDownY;
        }
        //when the mouse moves over image
        IconImage[ChosenIcon]->Hint = tmp->ReadString("Icon "+IntToStr(ChosenIcon),"Name","");
        StatusBar1->Panels->Items[1]->Text = "Icon "+IntToStr(image->Tag);
        StatusBar1->Panels->Items[2]->Text = "X: "+IntToStr(IconImage[ChosenIcon]->Left);
        StatusBar1->Panels->Items[3]->Text = "Y: "+IntToStr(IconImage[ChosenIcon]->Top);
     //   Refresh();
}
//------------------------------------------------------------ On image Mouse Up
void __fastcall TForm1::ImageMouseUp(TObject *Sender,
	  TMouseButton Button, TShiftState Shift, int X, int Y)
{
        //if visualization runs
        if(runs)
        {
           if(Button == mbLeft)
           RunImage("OnMouseUp");
           return;
        }
        MouseIsDown = false;
        ObjectIsChosen = false;
        //check if possition changed
        if(IconImage[ChosenIcon]->Left == tmp->ReadString("Icon "+IntToStr(ChosenIcon),"PositionX","")
           && IconImage[ChosenIcon]->Top == tmp->ReadString("Icon "+IntToStr(ChosenIcon),"PositionY",""))
           return;
        //save new position to tmp
        tmp->WriteInteger("Icon "+IntToStr(ChosenIcon),"PositionX",IconImage[ChosenIcon]->Left);
        tmp->WriteInteger("Icon "+IntToStr(ChosenIcon),"PositionY",IconImage[ChosenIcon]->Top);
        //project modified
        ProjectModified(1);
}
//------------------------------------------------------------------------------
//      TEXT
//------------------------------------------------------------------------------
void __fastcall RunText(AnsiString event)
{
        if(event == "OnMouseDown" || event == "OnMouseUp")
        {
           //page command
           if(Function_PAGE("Text",ChosenText,event));

           //rgb window command
           else if(Function_RGB("Text",ChosenText,event));

           //web window command
           else if(Function_APP("Text",ChosenText,event));

           //string commnad
           else
           {
              //send command
              ReadHexFromTmp(("Text "+IntToStr(ChosenText)),event);    //get message from tmp
              if(TmpString != "")                                      //empty string?
                 SendToBus(TmpHex[0],TmpHex[1],TmpHex[2],TmpHex[3],TmpHex[4],TmpHex[5],TmpHex[6],TmpHex[7],TmpHex[8],TmpHex[9],TmpHex[10],TmpHex[11]);
              if(event == "OnMouseUp")
              {
                 Form1->Timer2->Enabled = true;                        //count main form disable time
                 Form1->Enabled = false;
              }
           }
        }
}
//---------------------------------------------------------------------------
void __fastcall ReadTextFunction(void)
{
        //read temperature
        if(TmpString == "Temp()")
        {
           byte MSB = BufferIn[7];
           byte LSB = BufferIn[8];
           if((BufferIn[7] & 0x80) == 0x80)             //negative
           {
              WORD TEMP = MSB*256+LSB;
              TEMP = ~TEMP+1;
              MSB = TEMP/256;
              LSB = TEMP;
              TmpString = "-"+IntToStr(MSB*16+(LSB/16))+"."
              +IntToStr((LSB&0x0F)*625/1000)+"�C";
           }
           else                                         //positive
           {
              TmpString = IntToStr(MSB*16+(LSB/16))+"."
              +IntToStr((LSB&0x0F)*625/1000)+"�C";
           }
        }
        if(TmpString == "Therm()")
        {
           if((BufferIn[9] & 0x80) == 0x80)             //negative
           {
              BYTE THERM = BufferIn[9];
              THERM = ~THERM+1;
              TmpString = "-"+IntToStr(THERM)+"�C";
           }
           else                                         //positive
              TmpString = IntToStr(BufferIn[9])+"�C";
        }

}
//---------------------------------------------------------------------------
void __fastcall StatusText(void)
{
        for(int i=0; i<MaxTextNo; i++)                                          //check all texts
        {
           if(IconText[i]->Parent == PagePanel[Form1->PageControl1->ActivePageIndex])  //look only for icons on active page
           {
              ReadHexFromTmp("Text "+IntToStr(i),"If1");                           //read from file If1 value
              if(CompareMessages(BufferIn,TmpChar)==true)
              {
                 ReadHexFromTmp("Text "+IntToStr(i),"ShowText1");
                 ReadTextFunction();
                 IconText[i]->Caption = TmpString;
              }
              ReadHexFromTmp("Text "+IntToStr(i),"If2");                           //read from file If2 value
              if(CompareMessages(BufferIn,TmpChar)==true)
              {
                 ReadHexFromTmp("Text "+IntToStr(i),"ShowText2");
                 ReadTextFunction();
                 IconText[i]->Caption = TmpString;
              }
              ReadHexFromTmp("Text "+IntToStr(i),"If3");                           //read from file If2 value
              if(CompareMessages(BufferIn,TmpChar)==true)
              {
                 ReadHexFromTmp("Text "+IntToStr(i),"ShowText3");
                 ReadTextFunction();
                 IconText[i]->Caption = TmpString;
              }
           }
        }   
}
//----------------------------------------------------------- On text Mouse Down
void __fastcall TForm1::TextMouseDown(TObject *Sender,
	  TMouseButton Button, TShiftState Shift, int X, int Y)
{
        //image where the mouse was downed and parameters
        TLabel *tekst = dynamic_cast<TLabel*>(Sender);
        ChosenText = tekst->Tag;

        //if visualization runs
        if(runs)
        {
           if(Button == mbLeft)
           RunText("OnMouseDown");
           return;
        }
        ObjectDownX = X;
        ObjectDownY = Y;
        MouseIsDown = true;

        if (Button == mbLeft)
	   ObjectIsChosen = true;
        if (Button == mbRight)
        {
           TextMenu->Items->Items[0]->Caption = "Text "+IntToStr(tekst->Tag);
           TextMenu->Items->Items[0]->Enabled = 0;
           TextMenu->Popup(X+Form1->Left+IconText[ChosenText]->Left+5,Y+Form1->Top+IconText[ChosenText]->Top+50);
        }
}
//----------------------------------------------------------- On text Mouse Move
void __fastcall TForm1::TextMouseMove(TObject *Sender,
	  TShiftState Shift, int X, int Y)
{
        TLabel *tekst = dynamic_cast<TLabel*>(Sender);
        ChosenText = tekst->Tag;
        if (ObjectIsChosen)             //drag
        {
	   //this drags the image
	   tekst->Left = tekst->Left + X - ObjectDownX;
	   tekst->Top = tekst->Top + Y - ObjectDownY;
        }
        //when the mouse moves over image
        IconText[ChosenText]->Hint = tmp->ReadString("Text "+IntToStr(ChosenText),"Name","");
        StatusBar1->Panels->Items[1]->Text = "Text "+IntToStr(tekst->Tag);
        StatusBar1->Panels->Items[2]->Text = "X: "+IntToStr(IconText[ChosenText]->Left);
        StatusBar1->Panels->Items[3]->Text = "Y: "+IntToStr(IconText[ChosenText]->Top);
     //   Refresh();
}
//------------------------------------------------------------- On text Mouse Up
void __fastcall TForm1::TextMouseUp(TObject *Sender,
	  TMouseButton Button, TShiftState Shift, int X, int Y)
{
        //if visualization runs
        if(runs)
        {
           if(Button == mbLeft)
           RunText("OnMouseUp");
           return;
        }
        MouseIsDown = false;
        ObjectIsChosen = false;
        //check if possition changed
        if(IconText[ChosenText]->Left == tmp->ReadString("Text "+IntToStr(ChosenText),"PositionX","")
           && IconText[ChosenText]->Top == tmp->ReadString("Text "+IntToStr(ChosenText),"PositionY",""))
           return;
        //save new position to tmp
        tmp->WriteInteger("Text "+IntToStr(ChosenText),"PositionX",IconText[ChosenText]->Left);
        tmp->WriteInteger("Text "+IntToStr(ChosenText),"PositionY",IconText[ChosenText]->Top);
        //project modified
        ProjectModified(1);
}
//------------------------------------------------------------------------------
//      GAUGE
//------------------------------------------------------------------------------
void __fastcall RunGauge(AnsiString event)
{
        if(event == "OnMouseDown" || event == "OnMouseUp")
        {
           //page command
           if(Function_PAGE("Gauge",ChosenGauge,event));

           //rgb window command
           else if(Function_RGB("Gauge",ChosenGauge,event));

           //web window command
           else if(Function_APP("Gauge",ChosenGauge,event));

           //string commnad
           else
           {
              //send command
              ReadHexFromTmp(("Gauge "+IntToStr(ChosenGauge)),event);    //get message from tmp
              if(TmpString != "")                                        //empty string?
                 SendToBus(TmpHex[0],TmpHex[1],TmpHex[2],TmpHex[3],TmpHex[4],TmpHex[5],TmpHex[6],TmpHex[7],TmpHex[8],TmpHex[9],TmpHex[10],TmpHex[11]);
              if(event == "OnMouseUp")
              {
                 Form1->Timer2->Enabled = true;                        //count main form disable time
                 Form1->Enabled = false;
              }                 
           }
        }
}
//---------------------------------------------------------------------------
void __fastcall StatusGauge(void)
{
        for(int i=0; i<MaxGaugeNo; i++)                                         //check all texts
        {
           if(IconGauge[i]->Parent == PagePanel[Form1->PageControl1->ActivePageIndex])  //look only for icons on active page
           {
              ReadHexFromTmp("Gauge "+IntToStr(i),"ShowValueIf");                  //read from file "" value
              if(CompareMessages(BufferIn,TmpChar)==true)
              {
                 int j;
                 for(j=0; j<12; j++)
                 {
                    if(TmpChar[3*j]==63)              //find where "?" is
                       break;
                 }
                 gauge[i]->Progress = BufferIn[j];
              }
           }   
        }
}
//---------------------------------------------------------- On Gauge Mouse Down
void __fastcall TForm1::GaugeMouseDown(TObject *Sender,
	  TMouseButton Button, TShiftState Shift, int X, int Y)
{
        //image where the mouse was downed and parameters
        TPanel *gauge = dynamic_cast<TPanel*>(Sender);
        ChosenGauge = gauge->Tag;

        //if visualization runs
        if(runs)
        {
           if(Button == mbLeft)
           RunGauge("OnMouseDown");
           return;
        }
        ObjectDownX = X;
        ObjectDownY = Y;
        MouseIsDown = true;

        if (Button == mbLeft)
	   ObjectIsChosen = true;
        if (Button == mbRight)
        {
           Form1->GaugeMenu->Items->Items[0]->Caption = "Gauge "+IntToStr(gauge->Tag);
           Form1->GaugeMenu->Items->Items[0]->Enabled = 0;
           Form1->GaugeMenu->Popup(X+Form1->Left+IconGauge[ChosenGauge]->Left+5,Y+Form1->Top+IconGauge[ChosenGauge]->Top+50);
        }
}
//----------------------------------------------------------- On Gauge Mouse Move
void __fastcall TForm1::GaugeMouseMove(TObject *Sender,
	  TShiftState Shift, int X, int Y)
{
        TPanel *gauge = dynamic_cast<TPanel*>(Sender);
        ChosenGauge = gauge->Tag;
        if (ObjectIsChosen)             //drag
        {
	   //this drags the image
	   gauge->Left = gauge->Left + X - ObjectDownX;
	   gauge->Top = gauge->Top + Y - ObjectDownY;
        }
        //when the mouse moves over image
        IconGauge[ChosenGauge]->Hint = tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"Name","");
        StatusBar1->Panels->Items[1]->Text = "Gauge "+IntToStr(gauge->Tag);
        StatusBar1->Panels->Items[2]->Text = "X: "+IntToStr(IconGauge[ChosenGauge]->Left);
        StatusBar1->Panels->Items[3]->Text = "Y: "+IntToStr(IconGauge[ChosenGauge]->Top);
        Update();
//        Refresh();


}
//------------------------------------------------------------- On Gauge Mouse Up
void __fastcall TForm1::GaugeMouseUp(TObject *Sender,
	  TMouseButton Button, TShiftState Shift, int X, int Y)
{
        //if visualization runs
        if(runs)
        {
           if(Button == mbLeft)
           RunGauge("OnMouseUp");
           return;
        }
        MouseIsDown = false;
        ObjectIsChosen = false;
        //check if possition changed
        if(IconGauge[ChosenGauge]->Left == tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"PositionX","")
           && IconGauge[ChosenGauge]->Top == tmp->ReadString("Gauge "+IntToStr(ChosenGauge),"PositionY",""))
           return;
        //save new position to tmp
        tmp->WriteInteger("Gauge "+IntToStr(ChosenGauge),"PositionX",IconGauge[ChosenGauge]->Left);
        tmp->WriteInteger("Gauge "+IntToStr(ChosenGauge),"PositionY",IconGauge[ChosenGauge]->Top);
        //project modified
        ProjectModified(1);
}
//------------------------------------------------------------------------------
//      MAIN MENU
//------------------------------------------------------------------------------
//--------------------------------------------------------------------- MENU New
void __fastcall TForm1::New1Click(TObject *Sender)
{
        //close existing project
        if(ProjectModifiedFlag==1)
           CloseProjectClick(Sender);
        //save new
        if(Form1->SaveDialog1->Execute()==NULL)
        Abort();
           //close existing project
           CloseProjectClick(Sender);
           //add header
           Memo1->Lines->SaveToFile(ChangeFileExt(Form1->SaveDialog1->FileName,".tmp"));
           //tmp ini type file
           tmp = new TIniFile(ChangeFileExt(Form1->SaveDialog1->FileName, ".tmp" ));
           //copy tmp to hav, allow overwrite
           CopyFile(ChangeFileExt(Form1->SaveDialog1->FileName,".tmp").c_str(),
                    Form1->SaveDialog1->FileName.c_str(),0);
           //filename
           ProjectFile = Form1->SaveDialog1->FileName;
           ProjectPath = ExtractFilePath(Form1->SaveDialog1->FileName);
           Form1->Caption = "HAPCAN Visualizer - "+ExtractFileName(ProjectFile);
           //show page
           Form1->PageControl1->Visible = true;
           Form1->PageControl1->Pages[0]->TabVisible = true;
           //project modified
           ProjectModified(0);
           MainMenu1->Items->Items[0]->Items[3]->Enabled = true;
           MainMenu1->Items->Items[0]->Items[4]->Enabled = true;
           Form1->MainMenu1->Items->Items[1]->Enabled = true;
           Form1->MainMenu1->Items->Items[2]->Enabled = true;

}
//-------------------------------------------------------------------- MENU Open
void __fastcall TForm1::Open1Click(TObject *Sender)
{
        //close existing project
        if(ProjectModifiedFlag==1)
           CloseProjectClick(Sender);
        if(Form1->OpenDialog1->Execute()==NULL)
        Abort();
           //close existing project
           CloseProjectClick(Sender);
           //copy hav to tmp, allow overwrite
           CopyFile(Form1->OpenDialog1->FileName.c_str(),
                   ChangeFileExt(Form1->OpenDialog1->FileName,".tmp").c_str(),0);
           //project modified
           ProjectModified(0);
           //other
           Form1->Caption = "HAPCAN Visualizer - "+ExtractFileName(OpenDialog1->FileName);
           ProjectFile = OpenDialog1->FileName;
           ProjectPath = ExtractFilePath(OpenDialog1->FileName);
           MainMenu1->Items->Items[0]->Items[3]->Enabled = true;
           MainMenu1->Items->Items[0]->Items[4]->Enabled = true;
           Form1->MainMenu1->Items->Items[1]->Enabled = true;
           Form1->MainMenu1->Items->Items[2]->Enabled = true;
           //icons                                              //read config file
           ReadTmpFile();
           //show logo
           PageControl1Change(Sender);
}
//-------------------------------------------------------------------- MENU Save
void __fastcall TForm1::SaveProjectClick(TObject *Sender)
{
        //change version
        tmp->WriteString("Application","Version",FormAbout->Version->Caption);
        //copy tmp to hav, allow overwrite
        CopyFile(ChangeFileExt(ProjectFile,".tmp").c_str(),
                 ProjectFile.c_str(),0);
        //project modified
        ProjectModified(0);
        MainMenu1->Items->Items[0]->Items[2]->Enabled = false;
}
//----------------------------------------------------------------- MENU Save As
void __fastcall TForm1::SaveAs1Click(TObject *Sender)
{
        AnsiString ProjectTmpFile = ChangeFileExt(ProjectFile,".tmp");
        //save new
        if(Form1->SaveDialog1->Execute()==NULL)
        Abort();
           //change version
           tmp->WriteString("Application","Version",FormAbout->Version->Caption);
           //copy old tmp to hav, allow overwrite
           CopyFile(ProjectTmpFile.c_str(),Form1->SaveDialog1->FileName.c_str(),0);
           //copy hav to new tmp, allow overwrite
           CopyFile(Form1->SaveDialog1->FileName.c_str(),ChangeFileExt(Form1->SaveDialog1->FileName,".tmp").c_str(),0);
           //project modified
           ProjectModified(0);
           //other
           Form1->Caption = "HAPCAN Visualizer - "+ExtractFileName(Form1->SaveDialog1->FileName);
           ProjectFile = Form1->SaveDialog1->FileName;
           ProjectPath = ExtractFilePath(Form1->SaveDialog1->FileName);
           MainMenu1->Items->Items[0]->Items[2]->Enabled = false;
           //delete old tmp file
           DeleteFile(ProjectTmpFile);
}
//------------------------------------------------------------------- MENU Close
void __fastcall TForm1::CloseProjectClick(TObject *Sender)
{
        if(ProjectModifiedFlag == 1)
        {
           switch (Application->MessageBox("Save current visualization?", "HAPCAN Visualizer", MB_YESNOCANCEL))
              {
                 case IDCANCEL: Abort();
                 case IDYES: SaveProjectClick(Sender); break;
              }
        }
        ProjectModified(0);
        //delete tmp file
        DeleteFile(ChangeFileExt(ProjectFile,".tmp"));
        //form caption
        Form1->Caption = "HAPCAN Visualizer";
        //menu
        MainMenu1->Items->Items[0]->Items[2]->Enabled = false;
        MainMenu1->Items->Items[0]->Items[3]->Enabled = false;
        MainMenu1->Items->Items[0]->Items[4]->Enabled = false;
        MainMenu1->Items->Items[1]->Enabled = false;
        MainMenu1->Items->Items[2]->Enabled = false;
        //hide pages
        Form1->PageControl1->Visible = false;        
        for(int i=0; i<MaxPageNo; i++)
           Form1->PageControl1->Pages[i]->TabVisible = false;
        //hide icons
        for(int i=0; i<MaxImageNo; i++)
           IconImage[i]->Visible = false;
        //hide texts
        for(int i=0; i<MaxTextNo; i++)
           IconText[i]->Visible = false;
        //hide gauges
        for(int i=0; i<MaxGaugeNo; i++)
           IconGauge[i]->Visible = false;
        //status bar
        for(int i=0; i<4; i++)
        StatusBar1->Panels->Items[i]->Text = "";
        //logo
        logo1->Parent = Form1;
        logo2->Parent = Form1;
        logo3->Parent = Form1;
}
//-------------------------------------------------------------------- MENU Exit
void __fastcall TForm1::ExitClick(TObject *Sender)
{
        Close();
}
//------------------------------------------------------------- MENU Insert Page
void __fastcall TForm1::InsertPage1Click(TObject *Sender)
{
        int i;
        //check available TabSheet
        for(i=0; i<MaxPageNo; i++)
        {
           if(Form1->PageControl1->Pages[i]->TabVisible == false)
           break;
        }
        //show info if all icons used
        if(i==MaxPageNo)
        {
           ShowMessage("Project reached maximum numer of Pages");
           return;
        }
        PageControl1->Pages[i]->TabVisible = true;
        PageControl1->Pages[i]->Show();

        //open icon properties form
        DialogCommand = "new";
        if(PageProperties->ShowModal()== mrCancel)     //delete
        {
           PageControl1->Pages[PageControl1->ActivePageIndex]->TabVisible = false;
           tmp->EraseSection("page "+IntToStr(PageControl1->ActivePageIndex));
        }
}

//------------------------------------------------------------- MENU Insert Icon
void __fastcall TForm1::InsertIconClick(TObject *Sender)
{
        //check available IconNo
        int i;
        for(i=0; i<MaxImageNo; i++)
        {
           if(IconImage[i]->Visible == false)
           break;
        }
        //show info if all icons used
        if(i==MaxImageNo)
        {
           ShowMessage("Project reached maximum numer of Icons");
           return;
        }
        IconImage[i]->Parent = PagePanel[PageControl1->ActivePageIndex];
        IconImage[i]->Picture = Form1->chip->Picture;
        IconImage[i]->Visible = true;
        IconImage[i]->BringToFront();

	//position of icon
	IconImage[i]->Left = 50;
	IconImage[i]->Top = 50;

        //open icon properties form
        ChosenIcon = i;
        DialogCommand = "new";
        if(ImageProperties->ShowModal()== mrCancel)      //delete
        {
           IconImage[ChosenIcon]->Visible = false;
           tmp->EraseSection("Icon "+IntToStr(ChosenIcon));
        }
}
//------------------------------------------------------------- MENU Insert Text
void __fastcall TForm1::Text1Click(TObject *Sender)
{
        //check available TextNo
        int i;
        for(i=0; i<MaxTextNo; i++)
        {
           if(IconText[i]->Visible == false)
           break;
        }
        //show info if all icons used
        if(i==MaxTextNo)
        {
           ShowMessage("Project reached maximum numer of Texts");
           return;
        }
        IconText[i]->Parent = PagePanel[PageControl1->ActivePageIndex];
        IconText[i]->Caption = "New Text";
        IconText[i]->Visible = true;
        IconText[i]->BringToFront();

	//position of icon
	IconText[i]->Left = 50;
	IconText[i]->Top = 50;

        //open icon properties form
        ChosenText = i;
        DialogCommand = "new";
        if(TextProperties->ShowModal()== mrCancel)      //delete
        {
           IconText[ChosenText]->Visible = false;
           tmp->EraseSection("Text "+IntToStr(ChosenText));
        }
}
//------------------------------------------------------------ MENU Insert Gauge
void __fastcall TForm1::Gauge1Click(TObject *Sender)
{
        //check available GaugeNo
        int i;
        for(i=0; i<MaxGaugeNo; i++)
        {
           if(IconGauge[i]->Visible == false)
           break;
        }
        //show info if all icons used
        if(i==MaxGaugeNo)
        {
           ShowMessage("Project reached maximum numer of this type objects");
           return;
        }
        IconGauge[i]->Parent = PagePanel[PageControl1->ActivePageIndex];
        IconGauge[i]->Visible = true;
        IconGauge[i]->BringToFront();

	//position of icon
	IconGauge[i]->Left = 50;
	IconGauge[i]->Top = 50;

        //open icon properties form
        ChosenGauge = i;
        DialogCommand = "new";
        if(GaugeProperties->ShowModal()== mrCancel)     //delete
        {
           IconGauge[ChosenGauge]->Visible = false;
           tmp->EraseSection("Gauge "+IntToStr(ChosenGauge));
        }
}
//--------------------------------------------------------- MENU Insert Settings
void __fastcall TForm1::Settings1Click(TObject *Sender)
{
        FormSettings->ShowModal();
}
//--------------------------------------------------------- MENU Visualize Start
void __fastcall TForm1::Start1Click(TObject *Sender)
{
        //check settings
        if(IP=="" || Port=="")
        {
           if(FormSettings->ShowModal()== mrCancel)
              return;
        }
        //TCP socket
        ClientSocket1->Address = DNSLookUp(IP);
        ClientSocket1->Port = StrToInt(Port);
        ClientSocket1->Open();
        //Other
        Form1->Align = alClient;
        Form1->BorderStyle = bsNone;
        MainMenu1->Items->Items[0]->Visible = 0;
        MainMenu1->Items->Items[1]->Visible = 0;
        MainMenu1->Items->Items[2]->Visible = 0;
        MainMenu1->Items->Items[3]->Visible = 0;
        PageControl1->Align = alNone;                                   //hide tabs
        PageControl1->Left = -2;
        PageControl1->Top = -2;
        PageControl1->Width = Form1->Width+2;
        PageControl1->Height = Form1->Height+60;
        PageControl1->Pages[0]->Show();
        Form1->Refresh();
        StatusBar1->Visible = false;
        runs = 1;
        //show logo
        logo1->Parent = PagePanel[Form1->PageControl1->ActivePageIndex];
        logo2->Parent = PagePanel[Form1->PageControl1->ActivePageIndex];
        logo3->Parent = PagePanel[Form1->PageControl1->ActivePageIndex];
        logo1->BringToFront();
        logo2->BringToFront();
        logo3->BringToFront();
}
//------------------------------------------------------------------- MENU About
void __fastcall TForm1::About1Click(TObject *Sender)
{
        FormAbout->ShowModal();
}
//------------------------------------------------------------------------------
//      POPUP MENUS
//------------------------------------------------------------------------------
//--------------------------------------------------------------- PopupMENU Page
void __fastcall TForm1::EditPageClick(TObject *Sender)
{
        DialogCommand = "edit";
        PageProperties->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DeletePageClick(TObject *Sender)
{
        if(Application->MessageBox("Delete Page?", "HAPCAN Visualizer", MB_YESNO)==IDNO)
        return;
        tmp->EraseSection("Page "+IntToStr(PageControl1->ActivePageIndex));
        PageControl1->Pages[PageControl1->ActivePageIndex]->TabVisible = false;
        ProjectModified(1);
}
//-------------------------------------------------------------- PopupMENU Image
void __fastcall TForm1::EditImageClick(TObject *Sender)
{
        DialogCommand = "edit";
        ImageProperties->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DeleteImageClick(TObject *Sender)
{
        if(Application->MessageBox("Delete Image?", "HAPCAN Visualizer", MB_YESNO)==IDNO)
        return;
        IconImage[ChosenIcon]->Visible = false;
        tmp->EraseSection("Icon "+IntToStr(ChosenIcon));
        ProjectModified(1);
}
//--------------------------------------------------------------- PopupMENU Text
void __fastcall TForm1::EditTextClick(TObject *Sender)
{
        DialogCommand = "edit";
        TextProperties->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DeleteTextClick(TObject *Sender)
{
        if(Application->MessageBox("Delete Text?", "HAPCAN Visualizer", MB_YESNO)==IDNO)
        return;
        IconText[ChosenText]->Visible = false;
        tmp->EraseSection("Text "+IntToStr(ChosenText));
        ProjectModified(1);
}
//-------------------------------------------------------------- PopupMENU Gauge
void __fastcall TForm1::DeleteGaugeClick(TObject *Sender)
{
        if(Application->MessageBox("Delete Gauge?", "HAPCAN Visualizer", MB_YESNO)==IDNO)
        return;
        IconGauge[ChosenGauge]->Visible = false;
        tmp->EraseSection("Gauge "+IntToStr(ChosenGauge));
        ProjectModified(1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::EditGaugeClick(TObject *Sender)
{
        DialogCommand = "edit";
        GaugeProperties->ShowModal();
}
//------------------------------------------------------------------------------
//      FORM
//------------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
        //delete tmp file
        delete tmp;
        DeleteFile(ChangeFileExt(Form1->SaveDialog1->FileName,".tmp"));
        Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCloseQuery(TObject *Sender, bool &CanClose)
{
        //close existing project
        CloseProjectClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ClientSocket1Connect(TObject *Sender,
      TCustomWinSocket *Socket)
{
        StatusBar1->Panels->Items[0]->Text = "Connected";
        Timer1Timer(Sender);                             //start timer
        logo1->Picture = logo1on->Picture;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
        //send something every 30s to keep connection
        SendToBus(0xFF,0xFF,PcNode,PcGroup,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF);
        Timer1->Enabled = 1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer2Timer(TObject *Sender)
{
        //timer keeps main form disabled for some time
        Timer2->Interval = FreezeTime;
        Timer2->Enabled = false;
        Form1->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ClientSocket1Error(TObject *Sender,
      TCustomWinSocket *Socket, TErrorEvent ErrorEvent, int &ErrorCode)
{
        ClientSocket1->Close();
        logo1->Picture = logo1off->Picture;
        StatusBar1->Color = clRed;
        StatusBar1->Visible = true;
        StatusBar1->Panels->Items[0]->Text = "Disconnected";
        switch (ErrorCode)
        {
           case 10053:
              StatusBar1->Panels->Items[0]->Text = "Disconnected - Error: Connection is aborted due to timeout or other failure.";
              Abort();
           case 10054:
              StatusBar1->Panels->Items[0]->Text = "Disconnected - Error: Connection is reset by remote side.";
              Abort();
           case 10060:
              StatusBar1->Panels->Items[0]->Text = "Disconnected - Error: The attempt to connect timed out.";
              Abort();
           case 10061:
              StatusBar1->Panels->Items[0]->Text = "Disconnected - Error: Connection is forcefully rejected.";
              Abort();
           case 10065:
              StatusBar1->Panels->Items[0]->Text = "Disconnected - Error: No route To host.";
              Abort();
           default:
              StatusBar1->Panels->Items[0]->Text = "Disconnected - Error: " + IntToStr(ErrorCode);
              Abort();
         }
                 StatusBar1->Visible = true;
                 StatusBar1->Update();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ClientSocket1Read(TObject *Sender,
      TCustomWinSocket *Socket)
{
        int size;                                                               //numer of received bytes
        int pos;                                                                //current position in receive IP buffer
        unsigned char checksum;                                                 //hapcan frame checksum

        if(ClientSocket1->Socket->ReceiveLength()<1)                            //something is wrong, so exit
           return;

        //Receive
        while(ClientSocket1->Socket->ReceiveLength()>0)
        {
           size = ClientSocket1->Socket->ReceiveLength();                       //numer of received bytes
           ClientSocket1->Socket->ReceiveBuf(BufferIP,size);
           pos = 0;                                                             //after receiving start from 0

           //Add bytes that remained from last receive
           if(remaining>0)
           {
              size = size + remaining;                                          //total size equals remainig bytes + just received
              for(int i=size; i>=remaining; i--)                                //move buffer to make space for remainig bytes at the begining
                 BufferIP[i]=BufferIP[i-remaining];
              for (int i=0; i<remaining; i++)                                   //put remaing bytes
                 BufferIP[i]=BufferIPRem[i];
              remaining = 0;
           }

           //Find HAPCAN frame
              for(pos=0; pos<size; pos++)                                       //find frame boundry (start & stop bytes)
              {
                 if(size-pos>14)                                                //at least one frame in buffer?
                 {
                    if(BufferIP[pos]==0xAA && BufferIP[pos+14]==0xA5)           //start and stop found?
                    {
                       checksum=0;                                              //calculate checksum
                       for(int j=1; j<13; j++)
                          checksum += BufferIP[pos+j];

                       if(BufferIP[pos+13]==checksum)                           //checksum ok?
                       {
                          for(int j=0; j<13; j++)                               //remove start stop and checksum from frame
                             BufferIn[j]=BufferIP[pos+1+j];

                          pos=pos+14;

                          //BUFFER READY TO PROCEED
                          StatusImage();
                          StatusText();
                          StatusGauge();

                       }
                    }
                 }
                 else                                                           //not enought byte to make frame, so save them for later
                 {
                    for(int j=0; j<size-pos; j++)
                       BufferIPRem[j]=BufferIP[pos+j];
                    remaining = size-pos;
                    break;
                 }
              }
        }
}
//------------------------------------------------------------- Exit Visual Mode
void __fastcall TForm1::logo1Click(TObject *Sender)
{
        if(runs)
           FormMenu->ShowModal();                       //menu
        else
           Start1Click(Sender);                         //run
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
        if (Key == VK_ESCAPE)
        {
           if(runs)
              logo1Click(Sender);
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
        //check i hav file is as parameter
        if(LowerCase(ExtractFileExt(ParamStr(1))) == ".hav")
        {
           //opened file
           ProjectFile = ParamStr(1);
           ProjectPath = ExtractFilePath(ProjectFile);
           //copy hav to tmp, allow overwrite
           CopyFile(ProjectFile.c_str(),ChangeFileExt(ProjectFile,".tmp").c_str(),0);
           //project modified
           ProjectModified(0);
           //other
           Form1->Caption = "HAPCAN Visualizer - "+ExtractFileName(ProjectFile);
           Form1->MainMenu1->Items->Items[0]->Items[3]->Enabled = true;
           Form1->MainMenu1->Items->Items[0]->Items[4]->Enabled = true;
           Form1->MainMenu1->Items->Items[1]->Enabled = true;
           Form1->MainMenu1->Items->Items[2]->Enabled = true;
           //icons
           ReadTmpFile();
           //run
           Start1Click(Sender);

        }
        else
        {
           MainMenu1->Items->Items[0]->Items[2]->Enabled = false;
           MainMenu1->Items->Items[0]->Items[3]->Enabled = false;
           MainMenu1->Items->Items[0]->Items[4]->Enabled = false;
           MainMenu1->Items->Items[1]->Enabled = false;
           MainMenu1->Items->Items[2]->Enabled = false;
        }
        FormResize(Sender);
}
//------------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
        //LOGO
        logo1->Picture = logo1off->Picture;
        logo1->Left = Form1->Width-230;        //image ofline
        logo2->Left = Form1->Width-190;        //hapcan
        logo3->Left = Form1->Width-190;        //home automation
}
//---------------------------------------------------------------------------
int __fastcall Status_Function(Pointer Parameter)
{
        NodeDataBase = "";                   //this keeps all IDs of nodes on current page

     //send status request to all images on active page
        for(int n=0; n<MaxImageNo; n++)                                         //check all images
        {
           if(IconImage[n]->Parent == PagePanel[Form1->PageControl1->ActivePageIndex])  //ask only icons on active page
           {
              //Expected response for ShowImage1
              ReadHexFromTmp("Icon "+IntToStr(n),"If1");                        //read ID
              if(TmpString != "")
              {
                 NodeID = "("+IntToStr(TmpHex[2])+","+IntToStr(TmpHex[3])+")";
                 if(NodeDataBase.Pos(NodeID) == 0)                              //ID not in string?
                 {
                    NodeDataBase += NodeID;                                     //add to string
                    SendToBus(0x10,0x90,PcNode,PcGroup,0xFF,0xFF,TmpHex[2],TmpHex[3],0xFF,0xFF,0xFF,0xFF);      //send request to node
                 }
              }
              Sleep(TimeOut);
           }
        }
     //send status request to all texts on this page
        for(int n=0; n<MaxTextNo; n++)                                          //check all images
        {
           if(IconText[n]->Parent == PagePanel[Form1->PageControl1->ActivePageIndex])  //ask only icons on active page
           {
              //Expected response for ShowText1
              ReadHexFromTmp("Text "+IntToStr(n),"If1");                        //read ID
              if(TmpString != "")
              {
                 NodeID = "("+IntToStr(TmpHex[2])+","+IntToStr(TmpHex[3])+")";
                 if(NodeDataBase.Pos(NodeID) == 0)                              //ID not in string?
                 {
                    NodeDataBase += NodeID;                                     //add to string
                    SendToBus(0x10,0x90,PcNode,PcGroup,0xFF,0xFF,TmpHex[2],TmpHex[3],0xFF,0xFF,0xFF,0xFF);      //send request to node
                 }
              }
              Sleep(TimeOut);
           }
        }
     //send status request to all gauges on this page
        for(int n=0; n<MaxGaugeNo; n++)                                         //check all images
        {
           if(IconGauge[n]->Parent == PagePanel[Form1->PageControl1->ActivePageIndex])  //ask only icons on active page
           {
              //Expected response for ShowValue
              ReadHexFromTmp("Gauge "+IntToStr(n),"ShowValueIf");               //read ID
              if(TmpString != "")
              {
                 NodeID = "("+IntToStr(TmpHex[2])+","+IntToStr(TmpHex[3])+")";
                 if(NodeDataBase.Pos(NodeID) == 0)                              //ID not in string?
                 {
                    NodeDataBase += NodeID;                                     //add to string
                    SendToBus(0x10,0x90,PcNode,PcGroup,0xFF,0xFF,TmpHex[2],TmpHex[3],0xFF,0xFF,0xFF,0xFF);      //send request to node
                 }
              }
              Sleep(TimeOut);
           }
        }
        PopUp->Close();
        Form1->Enabled = true;
        SuspendThread((HANDLE)Status_Thread);
        CloseHandle((HANDLE)Status_Thread);
        return true;
}
//------------------------------------------------------------------------------
void __fastcall TForm1::PageControl1Change(TObject *Sender)
{
        //show logo
        logo1->Parent = PagePanel[Form1->PageControl1->ActivePageIndex];
        logo2->Parent = PagePanel[Form1->PageControl1->ActivePageIndex];
        logo3->Parent = PagePanel[Form1->PageControl1->ActivePageIndex];
        logo1->BringToFront();
        logo2->BringToFront();
        logo3->BringToFront();

        //status request
        if(runs)
        {
           PopUp->Label1->Caption = "Please wait...";
           PopUp->Show();
           Form1->Enabled = false;      //freeze main form till end of thread
           Status_Thread = BeginThread(NULL,0,Status_Function,NULL,0,Status_ThreadID);
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PageControl1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
        if(runs)
           return;

        if (Button == mbRight)
        {
           Form1->PageMenu->Items->Items[0]->Caption = "Page "+IntToStr(PageControl1->ActivePageIndex);
           Form1->PageMenu->Items->Items[0]->Enabled = 0;
           Form1->PageMenu->Popup(X+Form1->Left+5,Y+Form1->Top+50);
        }
}
//---------------------------------------------------------------------------




