//---------------------------------------------------------------------------

#ifndef statusrqstH
#define statusrqstH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TStatusRequest : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TLabel *Label1;
private:	// User declarations
public:		// User declarations
        __fastcall TStatusRequest(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TStatusRequest *StatusRequest;
//---------------------------------------------------------------------------
#endif
