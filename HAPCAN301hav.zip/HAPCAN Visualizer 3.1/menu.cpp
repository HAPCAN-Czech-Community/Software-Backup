//---------------------------------------------------------------------------
//    HAPCAN - Home Automation Project Visualizer (http://hapcan.com)
//    Copyright (C) 2012 Jacek Siwilo
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "menu.h"
#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormMenu *FormMenu;

extern bool runs;               //flag when visualization runs
//---------------------------------------------------------------------------
__fastcall TFormMenu::TFormMenu(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormMenu::PanelReconnectClick(TObject *Sender)
{
        Close();
        Form1->Start1Click(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFormMenu::PanelEditClick(TObject *Sender)
{
        Form1->StatusBar1->Color = clBtnFace;
        Form1->StatusBar1->Visible = true;
        Form1->Align = alClient;
        Form1->BorderStyle = bsSizeable;
        Form1->MainMenu1->Items->Items[0]->Visible = 1;
        Form1->MainMenu1->Items->Items[1]->Visible = 1;
        Form1->MainMenu1->Items->Items[2]->Visible = 1;
        Form1->MainMenu1->Items->Items[3]->Visible = 1;
        Form1->ClientSocket1->Socket->Close();
        Form1->logo1->Picture = Form1->logo1off->Picture;
        Form1->StatusBar1->Panels->Items[0]->Text = "Disconnected";
        Form1->Timer1->Enabled = 0;
        Form1->PageControl1->Align = alClient;
        runs = 0;
        ReadTmpFile();                           //read all settings again
        Close();
}
//---------------------------------------------------------------------------
void __fastcall TFormMenu::PanelCancelClick(TObject *Sender)
{
        Close();
}
//---------------------------------------------------------------------------

