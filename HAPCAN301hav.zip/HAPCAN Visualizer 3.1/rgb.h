//---------------------------------------------------------------------------

#ifndef rgbH
#define rgbH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TWin_RGB : public TForm
{
__published:	// IDE-managed Components
        TImage *Image1;
        TPanel *PanelCancel;
        TLabel *Label4;
        TImage *Image4;
        void __fastcall Image1MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall PanelCancelClick(TObject *Sender);
        void __fastcall Image4Click(TObject *Sender);
        void __fastcall Label4Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TWin_RGB(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TWin_RGB *Win_RGB;
//---------------------------------------------------------------------------
#endif
